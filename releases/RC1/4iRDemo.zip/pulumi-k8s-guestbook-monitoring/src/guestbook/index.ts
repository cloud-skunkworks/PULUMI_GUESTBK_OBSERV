// guestbook/index.ts
// Aggregates the Guestbook application tier: ConfigMap (server.js) -> frontend
// Deployment/Service -> redis master -> redis replica. Returns a single typed
// `Guestbook` object that index.ts and the monitoring layer consume.

import * as k8s from "@pulumi/kubernetes";
import { createMetricsConfigMap } from "./metrics";
import { createFrontend, Frontend } from "./frontend";
import { createRedisMaster } from "./redis-master";
import { createRedisReplica } from "./redis-replica";

export interface GuestbookArgs {
    namespaceName: string;
    namespaceDependency: k8s.core.v1.Namespace;
    // Optional least-privilege SA for the frontend pod (from security/rbac.ts).
    frontendServiceAccountName?: string;
}

// Everything the rest of the program needs to know about the app tier. The monitoring
// layer only needs `frontend` (for ServiceMonitor selector + scrape target) and the
// namespace; the redis service names are surfaced for completeness/outputs.
export interface Guestbook {
    frontend: Frontend;
    redisMasterServiceName: string;
    redisReplicaServiceName: string;
    namespaceName: string;
}

export function createGuestbook(args: GuestbookArgs): Guestbook {
    // 1. ConfigMap holding the instrumented Node server.
    const metrics = createMetricsConfigMap(args.namespaceName, args.namespaceDependency);

    // 2. Backend: redis master then replica (replica points at master Service name).
    const redisMaster = createRedisMaster(args.namespaceName, args.namespaceDependency);
    const redisReplica = createRedisReplica(
        args.namespaceName,
        args.namespaceDependency,
        redisMaster.serviceName,
    );

    // 3. Frontend: runs server.js from the ConfigMap, exposes http + metrics ports.
    const frontend = createFrontend({
        namespaceName: args.namespaceName,
        namespaceDependency: args.namespaceDependency,
        metrics,
        serviceAccountName: args.frontendServiceAccountName,
    });

    return {
        frontend,
        redisMasterServiceName: redisMaster.serviceName,
        redisReplicaServiceName: redisReplica.serviceName,
        namespaceName: args.namespaceName,
    };
}
