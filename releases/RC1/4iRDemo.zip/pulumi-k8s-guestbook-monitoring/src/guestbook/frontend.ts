// guestbook/frontend.ts
// The instrumented Guestbook frontend: a Deployment running node:20-alpine that runs
// the server.js delivered by guestbook/metrics.ts (via ConfigMap volume), plus the
// Service that Prometheus scrapes.
//
// CRITICAL (SKILL section 20.3 — the #1 failure mode): the Service labels defined here
// are EXACTLY what the ServiceMonitor selects on. We compute them via the shared
// `appLabels("guestbook", "frontend")` helper and EXPORT them as `FRONTEND_SELECTOR_LABELS`
// so service-monitors.ts uses the identical object. Do not hand-edit one without the
// other — always go through the helper.

import * as k8s from "@pulumi/kubernetes";
import { appLabels } from "../namespaces";
import { MetricsConfigMap } from "./metrics";

// The label set that BOTH the frontend Service carries AND the ServiceMonitor selects.
// Exported so service-monitors.ts imports the very same values (no drift possible).
export const FRONTEND_SELECTOR_LABELS = appLabels("guestbook", "frontend");

// Named ports (SKILL section 12 / requirement: name the metrics port `metrics` and the
// app port `http`). Both target the same containerPort — the Node server serves both
// the app and /metrics on one socket.
export const FRONTEND_HTTP_PORT_NAME = "http";
export const FRONTEND_METRICS_PORT_NAME = "metrics";
// Stable cluster-internal port for the Service (what other in-cluster clients call).
export const FRONTEND_SERVICE_PORT = 80;

export interface Frontend {
    deployment: k8s.apps.v1.Deployment;
    service: k8s.core.v1.Service;
    serviceName: string;
    // Re-exported for the ServiceMonitor + outputs so callers don't re-derive them.
    selectorLabels: { [key: string]: string };
    metricsPortName: string;
    namespaceName: string;
}

export interface FrontendArgs {
    namespaceName: string;
    namespaceDependency: k8s.core.v1.Namespace;
    metrics: MetricsConfigMap;
    // Optional least-privilege ServiceAccount from security/rbac.ts. When undefined the
    // pod uses the namespace default SA.
    serviceAccountName?: string;
}

export function createFrontend(args: FrontendArgs): Frontend {
    const labels = FRONTEND_SELECTOR_LABELS;
    const name = "guestbook-frontend";
    const appPort = args.metrics.appContainerPort;

    const deployment = new k8s.apps.v1.Deployment(
        name,
        {
            metadata: { name, namespace: args.namespaceName, labels },
            spec: {
                replicas: 2,
                selector: { matchLabels: labels },
                template: {
                    metadata: { labels },
                    spec: {
                        serviceAccountName: args.serviceAccountName,
                        // Mount the server.js ConfigMap read-only at /app.
                        volumes: [
                            {
                                name: "server",
                                configMap: { name: args.metrics.configMapName },
                            },
                        ],
                        containers: [
                            {
                                name: "frontend",
                                image: "node:20-alpine",
                                // Run the mounted server. No build, no registry.
                                command: ["node", `/app/${args.metrics.serverFileName}`],
                                env: [{ name: "APP_PORT", value: `${appPort}` }],
                                volumeMounts: [
                                    { name: "server", mountPath: "/app", readOnly: true },
                                ],
                                // Two named ports, same containerPort: `http` (app) and
                                // `metrics` (scraped by the ServiceMonitor).
                                ports: [
                                    { name: FRONTEND_HTTP_PORT_NAME, containerPort: appPort },
                                    { name: FRONTEND_METRICS_PORT_NAME, containerPort: appPort },
                                ],
                                resources: {
                                    requests: { cpu: "50m", memory: "64Mi" },
                                    limits: { cpu: "200m", memory: "128Mi" },
                                },
                                // Probes hit /healthz (cheap, not counted as traffic).
                                readinessProbe: {
                                    httpGet: { path: "/healthz", port: FRONTEND_HTTP_PORT_NAME },
                                    initialDelaySeconds: 5,
                                    periodSeconds: 10,
                                },
                                livenessProbe: {
                                    httpGet: { path: "/healthz", port: FRONTEND_HTTP_PORT_NAME },
                                    initialDelaySeconds: 10,
                                    periodSeconds: 20,
                                },
                            },
                        ],
                    },
                },
            },
        },
        { dependsOn: [args.namespaceDependency, args.metrics.configMap] },
    );

    // The Service is the scrape target. Its labels (metadata.labels) are what the
    // ServiceMonitor `selector.matchLabels` matches — NOT the pod labels. Keep these
    // identical to FRONTEND_SELECTOR_LABELS.
    const service = new k8s.core.v1.Service(
        name,
        {
            metadata: { name, namespace: args.namespaceName, labels },
            spec: {
                type: "ClusterIP",
                // Expose both named ports. The ServiceMonitor scrapes `metrics`.
                ports: [
                    {
                        name: FRONTEND_HTTP_PORT_NAME,
                        port: FRONTEND_SERVICE_PORT,
                        targetPort: FRONTEND_HTTP_PORT_NAME,
                    },
                    {
                        name: FRONTEND_METRICS_PORT_NAME,
                        port: appPort,
                        targetPort: FRONTEND_METRICS_PORT_NAME,
                    },
                ],
                selector: labels,
            },
        },
        { dependsOn: [args.namespaceDependency] },
    );

    return {
        deployment,
        service,
        serviceName: name,
        selectorLabels: labels,
        metricsPortName: FRONTEND_METRICS_PORT_NAME,
        namespaceName: args.namespaceName,
    };
}
