// guestbook/redis-master.ts
// Redis master: the write side of the Guestbook backend (mirrors the upstream Pulumi
// guestbook example). The frontend in this project is a metrics demo and does not
// actually write to Redis, but we keep the full backend so the topology matches the
// reference app and so pod CPU/memory/restart metrics have a realistic backend to show.

import * as k8s from "@pulumi/kubernetes";
import { appLabels } from "../namespaces";

export interface RedisMaster {
    deployment: k8s.apps.v1.Deployment;
    service: k8s.core.v1.Service;
    serviceName: string;
}

export function createRedisMaster(
    namespaceName: string,
    namespaceDependency: k8s.core.v1.Namespace,
): RedisMaster {
    const labels = appLabels("redis", "master");
    const name = "redis-master";

    const deployment = new k8s.apps.v1.Deployment(
        name,
        {
            metadata: { name, namespace: namespaceName, labels },
            spec: {
                replicas: 1,
                selector: { matchLabels: labels },
                template: {
                    metadata: { labels },
                    spec: {
                        containers: [
                            {
                                name: "redis-master",
                                image: "redis:7.2-alpine",
                                // Named port (SKILL section 12: named ports).
                                ports: [{ name: "redis", containerPort: 6379 }],
                                // Requests/limits (SKILL section 11.7).
                                resources: {
                                    requests: { cpu: "50m", memory: "64Mi" },
                                    limits: { cpu: "250m", memory: "128Mi" },
                                },
                                // TCP probes: Redis has no HTTP, so probe the port.
                                readinessProbe: {
                                    tcpSocket: { port: "redis" },
                                    initialDelaySeconds: 5,
                                    periodSeconds: 10,
                                },
                                livenessProbe: {
                                    tcpSocket: { port: "redis" },
                                    initialDelaySeconds: 15,
                                    periodSeconds: 20,
                                },
                            },
                        ],
                    },
                },
            },
        },
        { dependsOn: [namespaceDependency] },
    );

    const service = new k8s.core.v1.Service(
        name,
        {
            metadata: { name, namespace: namespaceName, labels },
            spec: {
                type: "ClusterIP",
                ports: [{ name: "redis", port: 6379, targetPort: "redis" }],
                selector: labels,
            },
        },
        { dependsOn: [namespaceDependency] },
    );

    return { deployment, service, serviceName: name };
}
