// guestbook/metrics.ts
// The honestly-instrumented frontend server source, delivered as a ConfigMap.
//
// WHY THIS APPROACH: the upstream Pulumi Guestbook frontend (gcr.io/google-samples/
// gb-frontend) is a PHP app that does NOT emit Prometheus metrics. Rather than
// fabricate metrics (forbidden by SKILL section 7.1 / failure mode section 20.7) or
// force a custom image build + registry push, we ship a tiny dependency-free Node.js
// HTTP server as a ConfigMap and run it on the stock `node:20-alpine` image. No build
// pipeline, no registry — `pulumi up` is fully self-contained.
//
// WHICH METRICS ARE REAL (emitted by THIS server, incremented per request served):
//   - guestbook_http_requests_total           (counter)
//   - guestbook_http_request_errors_total      (counter)
//   - guestbook_http_request_duration_seconds  (histogram)
// WHICH METRICS COME FROM ELSEWHERE (not emitted here, scraped by Prometheus from
// the cluster — used by the dashboard's CPU/memory/restart panels):
//   - container_cpu_usage_seconds_total / container_memory_working_set_bytes  -> cAdvisor/kubelet
//   - kube_pod_container_status_restarts_total                                -> kube-state-metrics
//
// The server listens on two logical surfaces but ONE port to keep it simple:
//   - "/"        the app (returns a small guestbook-ish page) -> port name `http`
//   - "/metrics" Prometheus text exposition                   -> ALSO served on `http`
// We still declare a separate named `metrics` port on the Service pointing at the
// same container port, because the ServiceMonitor scrapes the port named `metrics`
// and CNCF best practice (SKILL section 12) wants the metrics port explicitly named.

import * as k8s from "@pulumi/kubernetes";
import { appLabels } from "../namespaces";

// The container port the Node server binds to. Both the `http` and `metrics` named
// Service ports target this single containerPort.
export const APP_CONTAINER_PORT = 8080;

// Dependency-free Node 20 HTTP server. Kept as a template string so the entire app is
// declarative and visible in the Pulumi diff. Uses only the Node stdlib `http`.
//
// Maintainer note: histogram buckets are fixed (le=0.005..10,+Inf). Counters reset on
// pod restart — that is expected; PromQL rate() handles counter resets.
const SERVER_JS = `
'use strict';
const http = require('http');

const PORT = process.env.APP_PORT ? Number(process.env.APP_PORT) : 8080;

// --- Real, in-process metrics (no external libs) ---------------------------------
let requestsTotal = 0;        // guestbook_http_requests_total
let requestErrorsTotal = 0;   // guestbook_http_request_errors_total

// Histogram: cumulative bucket counts + running sum, in seconds.
const BUCKETS = [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10];
const bucketCounts = new Array(BUCKETS.length).fill(0);
let durationSum = 0;
let durationCount = 0;

function observeDuration(seconds) {
  durationSum += seconds;
  durationCount += 1;
  for (let i = 0; i < BUCKETS.length; i++) {
    if (seconds <= BUCKETS[i]) bucketCounts[i] += 1;
  }
}

// Render Prometheus text exposition format (v0.0.4).
function renderMetrics() {
  let out = '';
  out += '# HELP guestbook_http_requests_total Total HTTP requests served by the frontend.\\n';
  out += '# TYPE guestbook_http_requests_total counter\\n';
  out += 'guestbook_http_requests_total ' + requestsTotal + '\\n';

  out += '# HELP guestbook_http_request_errors_total Total failed HTTP requests (status >= 500 or handler error).\\n';
  out += '# TYPE guestbook_http_request_errors_total counter\\n';
  out += 'guestbook_http_request_errors_total ' + requestErrorsTotal + '\\n';

  out += '# HELP guestbook_http_request_duration_seconds Request latency distribution.\\n';
  out += '# TYPE guestbook_http_request_duration_seconds histogram\\n';
  let cumulative = 0;
  for (let i = 0; i < BUCKETS.length; i++) {
    cumulative = bucketCounts[i];
    out += 'guestbook_http_request_duration_seconds_bucket{le="' + BUCKETS[i] + '"} ' + cumulative + '\\n';
  }
  out += 'guestbook_http_request_duration_seconds_bucket{le="+Inf"} ' + durationCount + '\\n';
  out += 'guestbook_http_request_duration_seconds_sum ' + durationSum + '\\n';
  out += 'guestbook_http_request_duration_seconds_count ' + durationCount + '\\n';
  return out;
}

const server = http.createServer((req, res) => {
  const start = process.hrtime.bigint();

  // /metrics is NOT counted as an app request (avoids self-inflating counters from
  // Prometheus scrapes every 15s).
  if (req.url === '/metrics') {
    res.writeHead(200, { 'Content-Type': 'text/plain; version=0.0.4; charset=utf-8' });
    res.end(renderMetrics());
    return;
  }

  // Liveness/readiness probe target — cheap, not counted.
  if (req.url === '/healthz') {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('ok');
    return;
  }

  // --- Everything else is a "real" served request and is measured ---------------
  requestsTotal += 1;

  // Demo error surface: GET /error returns 500 so error-rate panels show signal.
  let status = 200;
  let body = '<html><body><h1>Guestbook</h1><p>Instrumented frontend. Try /metrics.</p></body></html>';
  if (req.url === '/error') {
    status = 500;
    body = 'simulated error';
    requestErrorsTotal += 1;
  }

  res.writeHead(status, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(body);

  const elapsedSeconds = Number(process.hrtime.bigint() - start) / 1e9;
  observeDuration(elapsedSeconds);
});

server.listen(PORT, () => {
  console.log('guestbook instrumented frontend listening on ' + PORT);
});
`;

// What this module returns. index.ts/frontend.ts need the ConfigMap (to mount) and
// its name (for the volume reference) plus the container port.
export interface MetricsConfigMap {
    configMap: k8s.core.v1.ConfigMap;
    configMapName: string;
    serverFileName: string;
    appContainerPort: number;
}

// Creates the ConfigMap holding server.js. Mounted read-only into the frontend pod.
export function createMetricsConfigMap(
    namespaceName: string,
    namespaceDependency: k8s.core.v1.Namespace,
): MetricsConfigMap {
    const serverFileName = "server.js";

    const configMap = new k8s.core.v1.ConfigMap(
        "guestbook-frontend-server",
        {
            metadata: {
                name: "guestbook-frontend-server",
                namespace: namespaceName,
                labels: appLabels("guestbook", "frontend"),
            },
            data: {
                [serverFileName]: SERVER_JS,
            },
        },
        { dependsOn: [namespaceDependency] },
    );

    return {
        configMap,
        configMapName: "guestbook-frontend-server",
        serverFileName,
        appContainerPort: APP_CONTAINER_PORT,
    };
}
