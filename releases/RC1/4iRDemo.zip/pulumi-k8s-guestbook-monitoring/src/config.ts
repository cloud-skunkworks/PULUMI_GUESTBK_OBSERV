// config.ts
// Single source of truth for all Pulumi config (SKILL section 6.3).
//
// Why this exists: every other module imports the typed `AppConfig` from here so we
// read config in exactly one place. To change a default or add a key, edit ONLY this
// file and the `GuestbookMonitoringConfig` interface below.
//
// Secrets: grafanaAdminPassword is read with `requireSecret` so Pulumi keeps it
// encrypted end-to-end and refuses to run if it was never set.

import * as pulumi from "@pulumi/pulumi";

// Grafana can be exposed three ways. ClusterIP means "no external service" -> the
// operator reaches Grafana with `kubectl port-forward` (safest default for local
// clusters and the most locked-down option for production behind an ingress).
export type GrafanaServiceType = "LoadBalancer" | "NodePort" | "ClusterIP";

// Pure-data, fully-typed view of stack config. Passed by value into every module so
// nothing else needs to touch the Pulumi config object directly.
export interface GuestbookMonitoringConfig {
    appNamespace: string;
    monitoringNamespace: string;
    grafanaServiceType: GrafanaServiceType;
    grafanaAdminUser: string;
    // Secret — never logged, never an unwrapped string.
    grafanaAdminPassword: pulumi.Output<string>;
    prometheusChartVersion: string;
    enableNetworkPolicies: boolean;
    enableDashboard: boolean;
    enableRbac: boolean;
    cloudProvider: string;
}

// Validate + normalise the service type so a typo in config fails loud here rather
// than producing a broken Service later.
function readGrafanaServiceType(raw: string | undefined): GrafanaServiceType {
    const value = (raw ?? "LoadBalancer").trim();
    if (value === "LoadBalancer" || value === "NodePort" || value === "ClusterIP") {
        return value;
    }
    throw new Error(
        `Invalid grafanaServiceType '${value}'. Use LoadBalancer | NodePort | ClusterIP. ` +
            `ClusterIP means access via 'kubectl port-forward'.`,
    );
}

// Reads the stack config once and returns the typed, defaulted view.
export function loadConfig(): GuestbookMonitoringConfig {
    const config = new pulumi.Config();

    return {
        // Namespaces (SKILL section 12: separate guestbook + monitoring).
        appNamespace: config.get("appNamespace") ?? "guestbook",
        monitoringNamespace: config.get("monitoringNamespace") ?? "monitoring",

        // Exposure (SKILL section 8.1). Default LoadBalancer for cloud; switch to
        // NodePort/ClusterIP on local clusters where LB stays <pending>.
        grafanaServiceType: readGrafanaServiceType(config.get("grafanaServiceType")),

        // Credentials. User has a safe default; password is a required secret.
        grafanaAdminUser: config.get("grafanaAdminUser") ?? "admin",
        grafanaAdminPassword: config.requireSecret("grafanaAdminPassword"),

        // Pin the chart version (NFR-010). Bump deliberately and re-test.
        prometheusChartVersion: config.get("prometheusChartVersion") ?? "65.1.1",

        // Optional features gated behind flags with safe (off-ish) defaults.
        enableNetworkPolicies: config.getBoolean("enableNetworkPolicies") ?? false,
        enableDashboard: config.getBoolean("enableDashboard") ?? true,
        enableRbac: config.getBoolean("enableRbac") ?? true,

        // Informational hint only; does not gate cloud-specific resources.
        cloudProvider: config.get("cloudProvider") ?? "local",
    };
}
