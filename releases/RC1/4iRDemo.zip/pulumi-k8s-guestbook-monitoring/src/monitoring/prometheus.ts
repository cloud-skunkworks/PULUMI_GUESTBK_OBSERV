// monitoring/prometheus.ts
// Deploys kube-prometheus-stack (Prometheus Operator + Prometheus + Grafana +
// kube-state-metrics + node-exporter + the ServiceMonitor/PodMonitor CRDs) via a
// Pulumi-managed Helm chart (SKILL section 6.2 — preferred option). We NEVER shell out
// to helm/kubectl.
//
// Why kube-prometheus-stack: a single chart gives us the Operator (so ServiceMonitors
// "just work"), Grafana, AND kube-state-metrics/cAdvisor scraping — which is exactly
// where the CPU/memory/restart dashboard panels get their data. The trade-off is a
// heavier install, but it is predictable and easier to verify than stitching several
// charts together.
//
// CRD ordering (SKILL failure mode section 20.5): the chart installs the ServiceMonitor
// CRD. service-monitors.ts depends on the object returned here so Pulumi creates the
// CRD-defining chart BEFORE any ServiceMonitor custom resource.

import * as k8s from "@pulumi/kubernetes";
import * as pulumi from "@pulumi/pulumi";
import { GuestbookMonitoringConfig, GrafanaServiceType } from "../config";

// The Helm RELEASE name. kube-prometheus-stack derives resource names from this, so we
// fix it to keep service names predictable for outputs and port-forward hints:
//   - Prometheus Service:  prometheus-operated   (stable, set by the Operator)
//   - Grafana Service:     <release>-grafana      => kps-grafana
//   - Operator/SVC labels: release: <release>     => used by the dashboard sidecar
export const HELM_RELEASE_NAME = "kps";
export const GRAFANA_SERVICE_NAME = `${HELM_RELEASE_NAME}-grafana`;
// `prometheus-operated` is the headless Service the Prometheus Operator always creates
// for the Prometheus StatefulSet, independent of release name.
export const PROMETHEUS_SERVICE_NAME = "prometheus-operated";
// Label the Operator stamps on resources it owns; the Grafana dashboard sidecar uses
// `release: kps` to discover dashboard ConfigMaps. service-monitors.ts also sets this
// label so the bundled Prometheus selects our ServiceMonitor.
export const RELEASE_LABEL = HELM_RELEASE_NAME;

export interface PrometheusStack {
    chart: k8s.helm.v3.Chart;
    prometheusServiceName: string;
    grafanaServiceName: string;
    releaseLabel: string;
    monitoringNamespaceName: string;
}

export interface PrometheusStackArgs {
    config: GuestbookMonitoringConfig;
    monitoringNamespaceName: string;
    monitoringNamespaceDependency: k8s.core.v1.Namespace;
    // When the dashboard feature is on, the sidecar must be enabled in Helm values.
    enableDashboardSidecar: boolean;
}

// Map our config service type to a Kubernetes Service type for Grafana. ClusterIP =>
// access via port-forward (no external exposure).
function grafanaServiceTypeValue(t: GrafanaServiceType): string {
    return t; // values are already valid k8s service types
}

export function createPrometheusStack(args: PrometheusStackArgs): PrometheusStack {
    const { config } = args;

    // Helm values. Kept minimal and commented so an SRE can see exactly what changed
    // from chart defaults.
    const values: { [key: string]: any } = {
        // ---- Grafana ----
        grafana: {
            // Admin credentials come from Pulumi config (secret). The chart accepts a
            // plain value here; Pulumi keeps it encrypted in state and never logs it.
            adminUser: config.grafanaAdminUser,
            adminPassword: config.grafanaAdminPassword,
            service: {
                // Exposure is config-driven (SKILL section 8.1).
                type: grafanaServiceTypeValue(config.grafanaServiceType),
            },
            // Dashboard sidecar: watches for ConfigMaps labelled `grafana_dashboard: "1"`
            // and auto-imports them (this is how dashboards.ts wires in our JSON).
            sidecar: {
                dashboards: {
                    enabled: args.enableDashboardSidecar,
                    // Discover dashboard ConfigMaps in ALL namespaces (our dashboard
                    // ConfigMap lives in the monitoring namespace).
                    searchNamespace: "ALL",
                    label: "grafana_dashboard",
                    labelValue: "1",
                },
            },
            // Modest resources so it schedules on small/local clusters.
            resources: {
                requests: { cpu: "100m", memory: "128Mi" },
                limits: { cpu: "500m", memory: "512Mi" },
            },
        },

        // ---- Prometheus ----
        prometheus: {
            prometheusSpec: {
                // IMPORTANT: by default the Operator's Prometheus only selects
                // ServiceMonitors that carry `release: <name>`. We turn the selector
                // OFF so our ServiceMonitor (in the monitoring namespace, with the
                // release label) is picked up reliably across cluster setups. This is
                // the simplest robust release-candidate choice. A stricter production
                // variant can keep Helm selectors enabled and label every ServiceMonitor
                // with `release: kps`.
                serviceMonitorSelectorNilUsesHelmValues: false,
                podMonitorSelectorNilUsesHelmValues: false,
                // Keep retention small; this is a demo, not long-term storage.
                retention: "6h",
                resources: {
                    requests: { cpu: "150m", memory: "512Mi" },
                    limits: { cpu: "1", memory: "1Gi" },
                },
            },
        },

        // Keep the install lean & portable for local clusters: the default rules are
        // fine, but disable the etcd/kubeScheduler/etc. scrape jobs that fail on
        // managed control planes (EKS/GKE/AKS) and local clusters where those
        // endpoints aren't reachable. This avoids noisy "down" targets.
        kubeEtcd: { enabled: false },
        kubeScheduler: { enabled: false },
        kubeControllerManager: { enabled: false },
        kubeProxy: { enabled: false },
        // kube-state-metrics + node-exporter stay ENABLED — they supply the pod CPU,
        // memory and restart metrics the dashboard relies on.
    };

    const chart = new k8s.helm.v3.Chart(
        HELM_RELEASE_NAME,
        {
            chart: "kube-prometheus-stack",
            version: config.prometheusChartVersion,
            namespace: args.monitoringNamespaceName,
            fetchOpts: {
                repo: "https://prometheus-community.github.io/helm-charts",
            },
            values,
        },
        { dependsOn: [args.monitoringNamespaceDependency] },
    );

    return {
        chart,
        prometheusServiceName: PROMETHEUS_SERVICE_NAME,
        grafanaServiceName: GRAFANA_SERVICE_NAME,
        releaseLabel: RELEASE_LABEL,
        monitoringNamespaceName: args.monitoringNamespaceName,
    };
}

// Helper used by outputs/grafana exposure: resolves the external address of the
// Grafana Service for LoadBalancer, or a port-forward hint otherwise. Kept here so the
// service-name knowledge stays with the chart that creates it.
export function describeGrafanaAccess(
    stack: PrometheusStack,
    serviceType: GrafanaServiceType,
): pulumi.Output<string> {
    const ns = stack.monitoringNamespaceName;
    const svc = stack.grafanaServiceName;

    if (serviceType === "LoadBalancer") {
        // Look up the live Service to read its ingress IP/hostname asynchronously.
        // We use `k8s.core.v1.Service.get` to read status.loadBalancer after creation.
        const live = k8s.core.v1.Service.get(`${svc}-lookup`, pulumi.interpolate`${ns}/${svc}`, {
            dependsOn: [stack.chart],
        });
        return live.status.apply((status) => {
            const ing = status?.loadBalancer?.ingress?.[0];
            const addr = ing?.ip ?? ing?.hostname;
            if (addr) {
                return `http://${addr}:80`;
            }
            // Common on local clusters: LB stays <pending>.
            return (
                `LoadBalancer EXTERNAL-IP pending. Use port-forward instead: ` +
                `kubectl port-forward -n ${ns} svc/${svc} 3000:80  then open http://localhost:3000`
            );
        });
    }

    if (serviceType === "NodePort") {
        // Read the assigned nodePort asynchronously.
        const live = k8s.core.v1.Service.get(`${svc}-lookup`, pulumi.interpolate`${ns}/${svc}`, {
            dependsOn: [stack.chart],
        });
        return live.spec.apply((spec) => {
            const np = spec?.ports?.find((p) => p.name === "http-web" || p.port === 80)?.nodePort;
            const portText = np ? `${np}` : "<assigned-node-port>";
            return (
                `NodePort: http://<any-node-ip>:${portText}  ` +
                `(fallback: kubectl port-forward -n ${ns} svc/${svc} 3000:80 -> http://localhost:3000)`
            );
        });
    }

    // ClusterIP: no external service — port-forward only.
    return pulumi.output(
        `ClusterIP (not externally exposed). Access via: ` +
            `kubectl port-forward -n ${ns} svc/${svc} 3000:80  then open http://localhost:3000`,
    );
}
