// security/network-policies.ts
// Optional NetworkPolicies (SKILL section 12 / section 14.6), gated behind
// config.enableNetworkPolicies. These only take effect on a CNI that ENFORCES
// NetworkPolicy (Calico, Cilium, etc.); on Docker Desktop / some minikube setups they
// are silently inert — hence opt-in with a safe `false` default.
//
// Policy intent (PCI-aligned, deny-by-default within the app namespace):
//   1. default-deny ingress for the whole guestbook namespace.
//   2. allow Prometheus (from the monitoring namespace) to scrape the frontend
//      `metrics` port — otherwise default-deny would break scraping.
//   3. allow the frontend pods to reach redis on 6379.
//
// To allow external traffic to the frontend, add an explicit ingress rule and route
// traffic through an approved ingress/controller. It is intentionally omitted here
// because the frontend Service is ClusterIP-only by default.

import * as k8s from "@pulumi/kubernetes";
import { appLabels } from "../namespaces";
import { GuestbookMonitoringConfig } from "../config";
import { FRONTEND_SELECTOR_LABELS } from "../guestbook/frontend";
import { APP_CONTAINER_PORT } from "../guestbook/metrics";

export interface NetworkPolicies {
    enabled: boolean;
}

export function createNetworkPolicies(
    config: GuestbookMonitoringConfig,
    appNamespaceName: string,
    monitoringNamespaceName: string,
    appNamespaceDependency: k8s.core.v1.Namespace,
    monitoringNamespaceDependency: k8s.core.v1.Namespace,
): NetworkPolicies {
    if (!config.enableNetworkPolicies) {
        return { enabled: false };
    }

    const labels = appLabels("guestbook", "network-policy");

    // 1. Default-deny all ingress in the guestbook namespace.
    new k8s.networking.v1.NetworkPolicy(
        "guestbook-default-deny-ingress",
        {
            metadata: { name: "default-deny-ingress", namespace: appNamespaceName, labels },
            spec: {
                podSelector: {}, // all pods in the namespace
                policyTypes: ["Ingress"],
                // No ingress rules => deny all ingress.
            },
        },
        { dependsOn: [appNamespaceDependency] },
    );

    // 2. Allow Prometheus (monitoring namespace) -> frontend metrics port.
    // Matches on the monitoring namespace's recommended label set.
    new k8s.networking.v1.NetworkPolicy(
        "guestbook-allow-prometheus-scrape",
        {
            metadata: { name: "allow-prometheus-scrape", namespace: appNamespaceName, labels },
            spec: {
                podSelector: { matchLabels: FRONTEND_SELECTOR_LABELS },
                policyTypes: ["Ingress"],
                ingress: [
                    {
                        from: [
                            {
                                namespaceSelector: {
                                    matchLabels: {
                                        "app.kubernetes.io/name": "monitoring",
                                        "app.kubernetes.io/part-of": "guestbook-monitoring",
                                    },
                                },
                            },
                        ],
                        ports: [{ protocol: "TCP", port: APP_CONTAINER_PORT }],
                    },
                ],
            },
        },
        { dependsOn: [appNamespaceDependency, monitoringNamespaceDependency] },
    );

    // 3. Allow frontend -> redis (egress to 6379 within the namespace).
    new k8s.networking.v1.NetworkPolicy(
        "guestbook-allow-frontend-to-redis",
        {
            metadata: { name: "allow-frontend-to-redis", namespace: appNamespaceName, labels },
            spec: {
                podSelector: { matchLabels: FRONTEND_SELECTOR_LABELS },
                policyTypes: ["Egress"],
                egress: [
                    {
                        to: [
                            {
                                podSelector: {
                                    matchLabels: { "app.kubernetes.io/name": "redis" },
                                },
                            },
                        ],
                        ports: [{ protocol: "TCP", port: 6379 }],
                    },
                    // Allow DNS so service names resolve.
                    {
                        ports: [
                            { protocol: "UDP", port: 53 },
                            { protocol: "TCP", port: 53 },
                        ],
                    },
                ],
            },
        },
        { dependsOn: [appNamespaceDependency] },
    );

    return { enabled: true };
}
