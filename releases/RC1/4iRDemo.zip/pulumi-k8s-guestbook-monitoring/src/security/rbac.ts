// security/rbac.ts
// Optional, least-privilege RBAC for the Guestbook frontend (SKILL section 12 RBAC,
// section 14.7 "avoid unnecessary cluster-admin"). Gated behind config.enableRbac.
//
// The instrumented frontend needs NO Kubernetes API access at runtime, so this creates
// a dedicated ServiceAccount with an EMPTY-permission Role (a namespaced Role that
// grants nothing). The point is auditability: the pod runs as a named identity rather
// than the namespace `default` SA, and the Role makes it explicit that zero cluster
// permissions are required. Bind extra rules here only if a future feature needs them.

import * as k8s from "@pulumi/kubernetes";
import { appLabels } from "../namespaces";
import { GuestbookMonitoringConfig } from "../config";

export interface FrontendRbac {
    serviceAccountName?: string;
}

export function createFrontendRbac(
    config: GuestbookMonitoringConfig,
    namespaceName: string,
    namespaceDependency: k8s.core.v1.Namespace,
): FrontendRbac {
    // Feature-gated: when disabled the frontend falls back to the default SA.
    if (!config.enableRbac) {
        return { serviceAccountName: undefined };
    }

    const labels = appLabels("guestbook", "frontend");
    const saName = "guestbook-frontend";

    const serviceAccount = new k8s.core.v1.ServiceAccount(
        "guestbook-frontend-sa",
        {
            metadata: { name: saName, namespace: namespaceName, labels },
            // The frontend never talks to the API server; no token automount needed.
            automountServiceAccountToken: false,
        },
        { dependsOn: [namespaceDependency] },
    );

    // Empty Role = explicitly zero permissions (least privilege, documented).
    const role = new k8s.rbac.v1.Role(
        "guestbook-frontend-role",
        {
            metadata: { name: saName, namespace: namespaceName, labels },
            rules: [],
        },
        { dependsOn: [namespaceDependency] },
    );

    new k8s.rbac.v1.RoleBinding(
        "guestbook-frontend-rolebinding",
        {
            metadata: { name: saName, namespace: namespaceName, labels },
            roleRef: { apiGroup: "rbac.authorization.k8s.io", kind: "Role", name: saName },
            subjects: [
                { kind: "ServiceAccount", name: saName, namespace: namespaceName },
            ],
        },
        { dependsOn: [serviceAccount, role] },
    );

    return { serviceAccountName: saName };
}
