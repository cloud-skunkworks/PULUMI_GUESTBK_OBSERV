// namespaces.ts
// Creates the two namespaces (SKILL section 12: separate `guestbook` and
// `monitoring`) and defines the canonical Kubernetes recommended label helpers
// (SKILL section 11.6) used across the whole project.
//
// Why labels live here: ServiceMonitor selectors must EXACTLY match the frontend
// Service labels (the #1 failure mode, SKILL section 20.3). Centralising the label
// builder guarantees the producer (the Service) and the consumer (the
// ServiceMonitor) compute identical label maps from the same code.

import * as k8s from "@pulumi/kubernetes";
import { GuestbookMonitoringConfig } from "./config";

// `part-of` ties every resource in this project together for auditing.
export const PART_OF = "guestbook-monitoring";
export const MANAGED_BY = "pulumi";

// Standard app labels (https://kubernetes.io/docs/concepts/overview/working-with-objects/common-labels/).
// `name` + `component` together are what the ServiceMonitor selects on, so keep this
// the ONLY place these strings are produced.
export function appLabels(name: string, component: string): { [key: string]: string } {
    return {
        "app.kubernetes.io/name": name,
        "app.kubernetes.io/component": component,
        "app.kubernetes.io/part-of": PART_OF,
        "app.kubernetes.io/managed-by": MANAGED_BY,
    };
}

// What namespaces.ts hands back to index.ts. Returning the Namespace objects (not
// just names) lets downstream resources depend on them implicitly via `metadata`.
export interface Namespaces {
    appNamespace: k8s.core.v1.Namespace;
    monitoringNamespace: k8s.core.v1.Namespace;
    appNamespaceName: string;
    monitoringNamespaceName: string;
}

export function createNamespaces(config: GuestbookMonitoringConfig): Namespaces {
    const appNamespace = new k8s.core.v1.Namespace("app-namespace", {
        metadata: {
            name: config.appNamespace,
            labels: appLabels("guestbook", "namespace"),
        },
    });

    const monitoringNamespace = new k8s.core.v1.Namespace("monitoring-namespace", {
        metadata: {
            name: config.monitoringNamespace,
            labels: appLabels("monitoring", "namespace"),
        },
    });

    return {
        appNamespace,
        monitoringNamespace,
        appNamespaceName: config.appNamespace,
        monitoringNamespaceName: config.monitoringNamespace,
    };
}
