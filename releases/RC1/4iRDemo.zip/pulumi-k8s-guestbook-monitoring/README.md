# Pulumi Kubernetes Guestbook Monitoring

A modular Pulumi TypeScript project that deploys the classic Kubernetes Guestbook
application (frontend + Redis master + Redis replica) and adds full observability
with **Prometheus and Grafana** via the **kube-prometheus-stack** Helm chart,
managed entirely through Pulumi.

The frontend is an honestly-instrumented Node.js service that emits **real**
Prometheus metrics (`guestbook_http_requests_total`,
`guestbook_http_request_errors_total`, `guestbook_http_request_duration_seconds`).
Pod CPU/memory come from cAdvisor and pod status from kube-state-metrics — both
shipped by the kube-prometheus-stack.

## Overview

This repository extends the upstream
[Pulumi Kubernetes Guestbook example](https://github.com/pulumi/examples/blob/master/kubernetes-ts-guestbook/README.md)
with a production-aware monitoring layer. The goals are:

- Deploy the Guestbook app to any Kubernetes cluster declaratively with Pulumi.
- Deploy Prometheus + Grafana through Pulumi-managed Helm (no out-of-band
  `helm install` or `kubectl apply` steps).
- Scrape the Guestbook frontend's `/metrics` endpoint using a Prometheus Operator
  `ServiceMonitor`.
- Expose Grafana through a configurable Kubernetes `Service` type.
- Output every access detail an operator needs from `pulumi stack output`.
- Document the design along TOGAF architecture domains for ease of audit.

## Release Candidate Principles

This release candidate is intentionally small and direct. Human readability and
day-one stability take priority over clever abstractions.

- Config is read once in `src/config.ts`; every other module receives typed values.
- Resource ownership is obvious: `guestbook/*` creates the app,
  `monitoring/*` creates Prometheus/Grafana, and `security/*` creates optional
  controls.
- The frontend uses the stock `node:20-alpine` image plus a ConfigMap-mounted
  server, so there is no image build, registry, or hidden deployment dependency.
- ServiceMonitor selectors import the same labels used by the Service to avoid
  the most common Prometheus target-missing failure.
- Grafana password handling fails closed through `requireSecret`; no default
  password is shipped.
- Chart versions are pinned and cloud-specific behavior is config-driven.

Two Kubernetes namespaces are used throughout:

| Namespace    | Contents |
|--------------|----------|
| `guestbook`  | Frontend deployment/service, Redis master, Redis replica. |
| `monitoring` | kube-prometheus-stack, Grafana dashboard ConfigMap, and the `ServiceMonitor` that selects the Guestbook namespace. |

## Architecture Summary

```text
            ┌──────────────────────────── namespace: guestbook ───────────────────────────┐
            │                                                                              │
  user ───▶ │  frontend Service (http, metrics)  ──▶  frontend Deployment (Node.js)        │
            │         │                                   │  GET /            (app traffic) │
            │         │                                   │  GET /metrics     (Prometheus)  │
            │         ▼                                   ▼                                 │
            │   redis-master Service ◀── writes      redis-replica Service ◀── reads        │
            └──────────────────────────────────────┬───────────────────────────────────────┘
                                                    │ ServiceMonitor (namespaceSelector: guestbook)
            ┌──────────────────────────── namespace: monitoring ◀──┘──────────────────────┐
            │                                                                              │
            │   Prometheus  ◀── scrapes /metrics every 15s ── (frontend, cAdvisor, KSM)     │
            │       ▲                                                                       │
            │       │ datasource                                                            │
            │   Grafana  ──▶  exposed via grafanaServiceType (LoadBalancer/NodePort/ClusterIP)
            └──────────────────────────────────────────────────────────────────────────────┘
```

The full TOGAF-style architecture (Business, Application, Data, Technology,
Security, Operations) lives in [`docs/architecture.md`](docs/architecture.md).

## Prerequisites

| Requirement | Notes |
|-------------|-------|
| Node.js LTS (18+) | Runs the Pulumi TypeScript program and `npm install`. |
| Pulumi CLI | `pulumi version` ≥ 3.x. Install from <https://www.pulumi.com/docs/install/>. |
| Kubernetes cluster | EKS, GKE, AKS, or local (kind / minikube / Docker Desktop). |
| Valid kubeconfig context | Pulumi uses the active context: `kubectl config current-context`. |
| Helm capability via Pulumi provider | No standalone Helm install needed — Pulumi's Kubernetes provider renders the chart. |
| kubectl | For verification and diagnostics. |
| Cloud CLI (optional) | `aws` / `gcloud` / `az` only if you need to provision or authenticate to a managed cluster. |

## Repository Structure

```text
pulumi-k8s-guestbook-monitoring/
├── README.md                     # This file
├── Pulumi.yaml                   # Project + config key manifest
├── Pulumi.dev.yaml.example       # Example stack config (copy, do not commit secrets)
├── package.json                  # Node dependencies (@pulumi/pulumi, @pulumi/kubernetes)
├── tsconfig.json                 # TypeScript compiler settings
├── src/
│   ├── index.ts                  # Entry point; wires app + monitoring + outputs
│   ├── config.ts                 # Single source of truth for Pulumi config + defaults
│   ├── namespaces.ts             # Creates guestbook + monitoring namespaces
│   ├── guestbook/                # Frontend, redis-master, redis-replica, metrics
│   ├── monitoring/               # prometheus.ts, grafana.ts, service-monitors.ts, dashboards.ts
│   ├── security/                 # Optional RBAC + NetworkPolicies
│   └── outputs.ts                # Exported stack outputs
├── dashboards/
│   └── guestbook-dashboard.json  # Grafana dashboard (request rate, errors, CPU, memory, restarts)
├── docs/
│   ├── architecture.md           # TOGAF-style architecture
│   ├── operations-runbook.md     # Deploy / rollout-check / remediation
│   ├── verification.md           # Prometheus target + Grafana checks
│   └── troubleshooting.md        # Common failure modes and fixes
└── tests/
    └── README.md                 # Validation checklist
```

## Configuration

Configuration is read in `src/config.ts`; the keys below are the contract. Every
key has a safe default except `grafanaAdminPassword`, which is a secret with **no
default** and must be set before `pulumi up`.

| Config key | Type | Default | Purpose |
|------------|------|---------|---------|
| `appNamespace` | string | `guestbook` | Namespace for the Guestbook application. |
| `monitoringNamespace` | string | `monitoring` | Namespace for the Prometheus/Grafana stack. |
| `grafanaServiceType` | string | `LoadBalancer` | Grafana exposure: `LoadBalancer`, `NodePort`, or `ClusterIP`. |
| `grafanaAdminUser` | string | `admin` | Grafana admin username. |
| `grafanaAdminPassword` | **secret** | _(none)_ | Grafana admin password. Set with `--secret`. |
| `prometheusChartVersion` | string | `65.1.1` | Pinned kube-prometheus-stack chart version. |
| `enableNetworkPolicies` | bool | `false` | Create NetworkPolicies (requires an enforcing CNI). |
| `enableDashboard` | bool | `true` | Provision the Guestbook Grafana dashboard. |
| `enableRbac` | bool | `true` | Create a least-privilege ServiceAccount/empty Role for the frontend. |
| `cloudProvider` | string | `local` | Platform hint: `aws`, `gcp`, `azure`, or `local`. |

Set configuration with `pulumi config set <key> <value>` (add `--secret` for the
password). See `Pulumi.dev.yaml.example` for a complete starting point — copy it
to `Pulumi.dev.yaml` and never commit a real password.

> **Local clusters:** set `grafanaServiceType NodePort` and `cloudProvider local`.
> A `LoadBalancer` will usually stay `<pending>` without a cloud load-balancer
> controller.

## Deployment Steps

```bash
npm install
pulumi stack init dev
pulumi config set appNamespace guestbook
pulumi config set monitoringNamespace monitoring
pulumi config set grafanaServiceType LoadBalancer
pulumi config set grafanaAdminUser admin
pulumi config set --secret grafanaAdminPassword 'ChangeMe-Use-A-Secret'
pulumi up
```

Review the preview, confirm, and wait for the stack to converge. The
kube-prometheus-stack CRDs are installed before any `ServiceMonitor` is created,
so a single `pulumi up` is sufficient. The operations runbook
([`docs/operations-runbook.md`](docs/operations-runbook.md)) documents rollout
checks and remediation.

## Accessing Grafana

After `pulumi up`, read the outputs:

```bash
pulumi stack output grafanaUrl
pulumi stack output grafanaAdminUser
pulumi stack output grafanaAdminPassword --show-secrets
```

- **LoadBalancer:** `grafanaUrl` resolves once the cloud assigns an external
  IP/hostname. Browse to `http://<external-ip>` and log in with the admin
  credentials above.
- **NodePort:** `grafanaUrl` reports the node port. Browse to
  `http://<node-ip>:<node-port>`.
- **ClusterIP / fallback:** port-forward:

  ```bash
  kubectl port-forward -n monitoring svc/<grafana-service> 3000:80
  # then open http://localhost:3000
  ```

> If `EXTERNAL-IP` is pending, use NodePort or `kubectl port-forward`. This is
> common on local clusters without a cloud load balancer implementation.

## Accessing Guestbook

```bash
pulumi stack output guestbookFrontendUrl
kubectl get svc -n guestbook
```

If the frontend Service is a `LoadBalancer` and the external IP is pending (local
clusters), port-forward instead:

```bash
kubectl port-forward -n guestbook svc/guestbook-frontend 8080:80
# then open http://localhost:8080
```

Refresh the app or request `/error` a few times to generate HTTP traffic that
the frontend records in its Prometheus counters.

## Verifying Prometheus Scraping

```bash
kubectl get pods -n guestbook
kubectl get pods -n monitoring
kubectl get svc -n monitoring
kubectl get servicemonitor -A
kubectl port-forward -n monitoring svc/prometheus-operated 9090:9090
```

In the Prometheus UI (`http://localhost:9090`):

1. Open Prometheus.
2. Go to **Status → Targets**.
3. Confirm the Guestbook frontend scrape target is `UP`.
4. Run these queries:
   - `up{namespace="guestbook"}`
   - `guestbook_http_requests_total`
   - `rate(guestbook_http_requests_total[5m])`

The detailed verification walkthrough is in
[`docs/verification.md`](docs/verification.md).

## Grafana Dashboard

When `enableDashboard` is `true`, the **Guestbook Overview** dashboard is
provisioned automatically into Grafana (via the kube-prometheus-stack dashboard
ConfigMap sidecar). Panels and their queries:

| Panel | PromQL |
|-------|--------|
| Request rate | `rate(guestbook_http_requests_total[5m])` |
| Error rate | `rate(guestbook_http_request_errors_total[5m])` |
| Request latency (P95) | `histogram_quantile(0.95, sum(rate(guestbook_http_request_duration_seconds_bucket[5m])) by (le))` |
| Pod CPU | `sum(rate(container_cpu_usage_seconds_total{namespace="guestbook"}[5m])) by (pod)` |
| Pod memory | `container_memory_working_set_bytes{namespace="guestbook"}` |
| Pod restarts | `kube_pod_container_status_restarts_total{namespace="guestbook"}` |

To verify: log into Grafana, confirm the Prometheus datasource is present, open
**Guestbook Overview**, generate Guestbook traffic, and confirm the panels move.

## Troubleshooting

Common failure modes are documented in
[`docs/troubleshooting.md`](docs/troubleshooting.md). Quick reference:

| Symptom | Likely cause | Fix |
|---------|--------------|-----|
| Target missing in Prometheus | ServiceMonitor selector ≠ Service labels | Align `app.kubernetes.io/name`/`component` labels. |
| `ServiceMonitor` CRD not found during `pulumi up` | CRDs not yet installed | Ensure chart (CRDs) deploys before the ServiceMonitor; `pulumi up` again. |
| Grafana `EXTERNAL-IP` pending | No cloud LB controller (local cluster) | Use `NodePort` or `kubectl port-forward`. |
| No app metrics, only pod metrics | Frontend `/metrics` not scraped | Check port name `metrics`, path `/metrics`, target UP. |

## Cleanup

```bash
pulumi destroy
pulumi stack rm dev
```

`pulumi destroy` removes all Kubernetes resources (app + monitoring stack + CRDs
managed by the chart). `pulumi stack rm dev` removes the stack and its config
state.

## Design Decisions

- **kube-prometheus-stack** was chosen over separate Prometheus + Grafana charts.
  It ships the Prometheus Operator, Prometheus, Grafana, Alertmanager,
  kube-state-metrics, node-exporter, and the `ServiceMonitor`/`PodMonitor` CRDs in
  one Pulumi-managed Helm release. That gives clean, label-based scrape
  configuration (`ServiceMonitor`) instead of hand-rolled scrape configs, at the
  cost of a heavier deployment — an acceptable trade for an auditable, operator-driven
  setup.
- **Honest instrumentation.** The base Guestbook frontend does not emit application
  metrics, so the frontend is replaced with a minimal instrumented Node.js service
  exposing `/metrics`. The code only claims metrics it actually emits.
- **Helm through Pulumi only.** No mixed `helm`/`kubectl` lifecycle — everything is
  declarative and reproducible via `pulumi up` / `pulumi destroy`.
- **Config-driven portability.** Cloud-specific behaviour (service type, provider
  hint) is isolated behind Pulumi config so the same code runs on EKS, GKE, AKS, or
  local clusters.

## Security Notes

- The Grafana admin password is a **Pulumi secret** (`pulumi config set --secret
  grafanaAdminPassword ...`). It is never hardcoded and is encrypted in stack state.
- The `grafanaAdminPassword` stack output is marked secret; reveal it only with
  `--show-secrets`.
- `LoadBalancer` can expose Grafana **publicly** on cloud clusters. For production,
  front Grafana with ingress + TLS and SSO/OIDC, and restrict source ranges.
- Prometheus is **not** exposed publicly by default — reach it via
  `kubectl port-forward`.
- Namespace boundaries (`guestbook` vs `monitoring`) isolate workloads. Optional
  `NetworkPolicies` (`enableNetworkPolicies true`) further restrict traffic on a
  CNI that enforces them.
- The chart installs some cluster-scoped resources (CRDs, ClusterRoles for the
  operator and kube-state-metrics). This is documented as a known requirement of
  the monitoring stack rather than an app-level privilege.
- Never commit `Pulumi.dev.yaml` containing a real password; commit only
  `Pulumi.dev.yaml.example`.

## Known Limitations

- Application request metrics exist **only because** the frontend is instrumented;
  the upstream Guestbook frontend would expose pod metrics only.
- Prometheus uses the chart's default retention and storage. Production needs
  persistent volumes, tuned retention, and (optionally) remote write.
- No alerting rules are shipped. Likely next-step alerts: `GuestbookDown`
  (`up{namespace="guestbook"} == 0`), high error rate, high P95 latency, and pod
  crash-looping.
- `LoadBalancer` exposure depends on a cloud controller; local clusters must use
  `NodePort` or port-forward.
- TLS/SSO for Grafana is recommended but should be implemented before production
  internet exposure.
