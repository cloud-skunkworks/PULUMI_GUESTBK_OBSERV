# Verification — Pulumi Kubernetes Guestbook Monitoring

This guide proves that Prometheus is scraping the Guestbook frontend and that
Grafana can query and visualise those metrics. Run it after `pulumi up`
completes. Namespaces: `guestbook` and `monitoring`.

---

## 1. Cluster-level checks

```bash
kubectl get pods -n guestbook      # frontend, redis-master, redis-replica Running/Ready
kubectl get pods -n monitoring     # prometheus, grafana, operator, kube-state-metrics Running
kubectl get svc -n monitoring      # grafana + prometheus services present
kubectl get servicemonitor -A      # guestbook-frontend ServiceMonitor present
```

Expected: all pods `Running` and `Ready`; a `ServiceMonitor` selecting the
Guestbook frontend exists in the `monitoring` namespace.

---

## 2. Prometheus target checks

Port-forward Prometheus (it is not exposed publicly by default):

```bash
kubectl port-forward -n monitoring svc/prometheus-operated 9090:9090
```

Open `http://localhost:9090` and:

1. Open Prometheus.
2. Go to **Status → Targets**.
3. Confirm the Guestbook frontend scrape target is listed and its state is `UP`.
   - The target should reference the `guestbook` namespace, the frontend Service,
     and the `metrics` endpoint scraping `/metrics`.
4. Run these PromQL queries in the **Graph** tab:

   | Query | Expectation |
   |-------|-------------|
   | `up{namespace="guestbook"}` | Returns `1` for the frontend target (the target is healthy). |
   | `guestbook_http_requests_total` | Returns a non-empty counter series once the app has served traffic. |
   | `rate(guestbook_http_requests_total[5m])` | Greater than 0 while traffic is flowing. |

If `up{namespace="guestbook"}` is `0` or absent, the target is down or the
ServiceMonitor is not matching — see [`troubleshooting.md`](troubleshooting.md).

### Generate traffic for the counters

```bash
kubectl port-forward -n guestbook svc/guestbook-frontend 8080:80
# Browser → http://localhost:8080 → refresh several times, then request /error once
```

Then re-run `rate(guestbook_http_requests_total[5m])` and confirm it is non-zero.

### Confirm infrastructure metrics are present

These come from cAdvisor and kube-state-metrics, not the app:

| Query | Source |
|-------|--------|
| `sum(rate(container_cpu_usage_seconds_total{namespace="guestbook"}[5m])) by (pod)` | cAdvisor (pod CPU). |
| `container_memory_working_set_bytes{namespace="guestbook"}` | cAdvisor (pod memory). |
| `kube_pod_container_status_restarts_total{namespace="guestbook"}` | kube-state-metrics (pod restarts). |

---

## 3. Grafana dashboard checks

Get Grafana access details and credentials:

```bash
pulumi stack output grafanaUrl
pulumi stack output grafanaAdminUser
pulumi stack output grafanaAdminPassword --show-secrets
```

If `grafanaUrl` is a `LoadBalancer` whose external IP is still pending (common on
local clusters), port-forward instead:

```bash
kubectl port-forward -n monitoring svc/<grafana-service> 3000:80
# then open http://localhost:3000
```

In Grafana:

1. Open Grafana and log in with the Pulumi-output credentials.
2. Go to **Connections → Data sources** and confirm a **Prometheus** datasource
   exists and tests OK.
3. Open the **Guestbook Overview** dashboard.
4. Generate Guestbook traffic (use the port-forward above and add entries).
5. Confirm the panels update with live data.

Expected panels and their queries:

| Panel | PromQL |
|-------|--------|
| Request rate | `rate(guestbook_http_requests_total[5m])` |
| Error rate | `rate(guestbook_http_request_errors_total[5m])` |
| Request latency (P95) | `histogram_quantile(0.95, sum(rate(guestbook_http_request_duration_seconds_bucket[5m])) by (le))` |
| Pod CPU | `sum(rate(container_cpu_usage_seconds_total{namespace="guestbook"}[5m])) by (pod)` |
| Pod memory | `container_memory_working_set_bytes{namespace="guestbook"}` |
| Pod restarts | `kube_pod_container_status_restarts_total{namespace="guestbook"}` |

---

## 4. Verification checklist

- [ ] All `guestbook` and `monitoring` pods are `Running`/`Ready`.
- [ ] The Guestbook frontend `ServiceMonitor` exists.
- [ ] Prometheus **Status → Targets** shows the Guestbook target `UP`.
- [ ] `up{namespace="guestbook"}` returns `1`.
- [ ] `guestbook_http_requests_total` returns data after traffic.
- [ ] `rate(guestbook_http_requests_total[5m])` is non-zero under traffic.
- [ ] Pod CPU and memory metrics are queryable.
- [ ] Grafana Prometheus datasource tests OK.
- [ ] The Guestbook Overview dashboard panels display and update with data.
