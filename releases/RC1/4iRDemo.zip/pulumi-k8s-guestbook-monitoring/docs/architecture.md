# Architecture — Pulumi Kubernetes Guestbook Monitoring

This document describes the solution along TOGAF architecture domains so cloud
architects, platform engineers, and implementation approvers can audit the design
quickly. The six domains —
Business, Application, Data, Technology, Security, and Operations — each map to a
concrete part of the codebase.

---

## 1. Business Architecture

**Purpose of this release candidate.** Extend the Pulumi Kubernetes Guestbook
example with Prometheus + Grafana observability, deployed entirely through Pulumi,
suitable for an SRE or platform engineer to deploy, verify, audit, and maintain.
The implementation favors direct, readable modules and stable day-one behavior
over optional complexity.

**Stakeholder expectations.**

| Stakeholder | Expectation |
|-------------|-------------|
| SRE / platform engineer | Deploy with one `pulumi up`, verify scraping, troubleshoot from docs. |
| Implementation approver | Validate Pulumi + Kubernetes + Grafana + Prometheus behavior against a checklist. |
| Cloud architect | Audit observability design across TOGAF domains and cloud portability. |

**Release success criteria.**

- Guestbook, Prometheus, and Grafana all deploy via Pulumi.
- Prometheus scrapes real Guestbook metrics and shows targets `UP`.
- Grafana is reachable, credentialed, and dashboards the release metrics.
- Documentation is clear enough to deploy and operate without the author.

**Operational value of monitoring the Guestbook app.** Monitoring turns the demo
app into something operable: request rate and error rate reveal user-facing health,
latency histograms surface degradation, and pod CPU/memory/restart metrics expose
resource pressure and crash loops. These are the same signals an SRE would use to
defend an SLO on a real payments-grade service.

---

## 2. Application Architecture

**Components.**

| Component | Role |
|-----------|------|
| Guestbook frontend | Instrumented Node.js service. Serves the app on `/` and Prometheus metrics on `/metrics`. Reads from the Redis replica, writes to the Redis master. |
| Redis master | Single write primary for guestbook entries. |
| Redis replica | Read-scaling replica(s) of the master. |
| Metrics endpoint | `/metrics` on the frontend, exposed through a named `metrics` Service port. |
| ServiceMonitor | Prometheus Operator CR that selects the frontend Service and tells Prometheus to scrape `/metrics`. |
| Grafana dashboard | "Guestbook Overview" — request rate, error rate, latency, CPU, memory, restarts. |

**Scrape / dashboard flow.**

```text
frontend pod (/metrics)
   ▲ scrape every 15s
Prometheus  ◀── ServiceMonitor (namespaceSelector: guestbook; selector: app labels)
   ▲ datasource query
Grafana ── Guestbook Overview dashboard ── operator's browser
```

The frontend exposes `guestbook_http_requests_total`,
`guestbook_http_request_errors_total`, and
`guestbook_http_request_duration_seconds`. The `ServiceMonitor` matches the
frontend Service by the recommended Kubernetes labels (`app.kubernetes.io/name:
guestbook`, `app.kubernetes.io/component: frontend`) and uses a `namespaceSelector`
for the `guestbook` namespace, since the CR lives alongside the monitoring stack.

**Modularity.** Application resources (`src/guestbook/*`) are separate from
monitoring resources (`src/monitoring/*`), and dashboards (`dashboards/*.json`,
loaded by `src/monitoring/dashboards.ts`) are separate from the core
Prometheus/Grafana deployment code — satisfying the separation-of-concerns
principle.

---

## 3. Data Architecture

**Metrics emitted by Guestbook (application metrics).**

| Metric | Type | Source |
|--------|------|--------|
| `guestbook_http_requests_total` | Counter | Instrumented frontend. |
| `guestbook_http_request_errors_total` | Counter | Instrumented frontend. |
| `guestbook_http_request_duration_seconds` | Histogram | Instrumented frontend. |

**Metrics scraped from the cluster (infrastructure metrics).**

| Metric | Type | Source |
|--------|------|--------|
| `container_cpu_usage_seconds_total` | Counter | cAdvisor / kubelet. |
| `container_memory_working_set_bytes` | Gauge | cAdvisor / kubelet. |
| `kube_pod_container_status_restarts_total` | Counter | kube-state-metrics. |

Application metrics and infrastructure metrics are kept conceptually separate per
observability best practice. Labels include namespace, pod, and component; no
high-cardinality labels (request IDs, user IDs) are used.

**Scrape path.** Prometheus scrapes the frontend's `/metrics` every 15s (driven by
the `ServiceMonitor`) and the cluster's cAdvisor/kube-state-metrics endpoints
(driven by the chart's built-in monitors). All samples land in Prometheus's local
time-series database.

**Time-series retention assumption.** The kube-prometheus-stack default retention
(typically ~10 days, in-cluster storage) applies. No persistent volume is assumed;
production should configure a PVC and tuned retention.

**Grafana query path.** Grafana's Prometheus datasource issues PromQL against
Prometheus; panels render the results. No data is duplicated into Grafana.

**No persistent business data beyond Guestbook sample state.** The Redis topology
is sample, disposable state only. No PII or card data is stored or placed in
metric labels.

---

## 4. Technology Architecture

**Kubernetes namespace model.**

| Namespace | Workloads |
|-----------|-----------|
| `guestbook` | frontend, redis-master, redis-replica. |
| `monitoring` | Prometheus Operator, Prometheus, Grafana, Alertmanager, kube-state-metrics, node-exporter, frontend `ServiceMonitor`. |

**Pulumi deployment model.** A single Pulumi TypeScript program
(`@pulumi/pulumi` + `@pulumi/kubernetes`) using the active kubeconfig context.
`src/index.ts` wires namespaces → guestbook → monitoring → security → outputs.
Config is centralized in `src/config.ts`.

**Helm chart deployment model.** kube-prometheus-stack is installed via a
Pulumi Kubernetes Helm release (chart version pinned by `prometheusChartVersion`,
default `65.1.1`). No out-of-band `helm`/`kubectl` lifecycle — everything is
declarative so `pulumi up`/`pulumi destroy` is the single control plane.

**Prometheus / Grafana service exposure.** Grafana's Service type is set by
`grafanaServiceType` (`LoadBalancer` | `NodePort` | `ClusterIP`). Prometheus is
ClusterIP-only by default and reached via port-forward.

**Cloud portability.**

| Cloud | LoadBalancer behaviour |
|-------|------------------------|
| AWS EKS | Provisions an ELB/NLB depending on annotations/controller. |
| GCP GKE | Provisions a Google Cloud external load balancer. |
| Azure AKS | Provisions an Azure Load Balancer public IP. |
| Local (kind/minikube/Docker Desktop) | May stay `<pending>`; use `NodePort` or `kubectl port-forward`. |

No cloud-specific resources are hardcoded; behaviour differs only through
`grafanaServiceType` and `cloudProvider` config.

---

## 5. Security Architecture

- **Pulumi secrets for Grafana admin password.** `grafanaAdminPassword` is set with
  `pulumi config set --secret`, encrypted in stack state, and exported as a secret
  output. It has no default — deployment fails closed rather than shipping a known
  password.
- **Namespace separation.** `guestbook` and `monitoring` isolate application and
  observability workloads.
- **RBAC assumptions.** An optional least-privilege ServiceAccount/Role for the
  frontend is created when `enableRbac` is true. The kube-prometheus-stack creates
  the cluster-scoped resources it needs (CRDs, operator ClusterRoles,
  kube-state-metrics ClusterRole) — documented as a monitoring-stack requirement,
  not an app privilege.
- **NetworkPolicy optional configuration.** `enableNetworkPolicies true` provisions
  policies restricting traffic between namespaces; requires a CNI that enforces
  them.
- **Do not commit credentials.** Only `Pulumi.dev.yaml.example` is committed;
  real `Pulumi.dev.yaml` with a password must stay out of source control.
- **Avoid exposing Grafana publicly without authentication.** `LoadBalancer` can
  expose Grafana publicly on cloud clusters. Production should use ingress + TLS +
  SSO/OIDC and restrict source ranges. Prometheus is not exposed publicly by
  default.

---

## 6. Operations Architecture

**Deployment commands.**

```bash
npm install
pulumi stack init dev
pulumi config set appNamespace guestbook
pulumi config set monitoringNamespace monitoring
pulumi config set grafanaServiceType LoadBalancer
pulumi config set grafanaAdminUser admin
pulumi config set --secret grafanaAdminPassword 'ChangeMe-Use-A-Secret'
pulumi up
```

**Verification commands.**

```bash
kubectl get pods -n guestbook
kubectl get pods -n monitoring
kubectl get servicemonitor -A
kubectl port-forward -n monitoring svc/prometheus-operated 9090:9090
# Prometheus → Status → Targets → guestbook target UP
# Query: up{namespace="guestbook"}, rate(guestbook_http_requests_total[5m])
```

See [`verification.md`](verification.md) for the full procedure.

**Rollback / destroy commands.**

```bash
pulumi destroy
pulumi stack rm dev
```

**Troubleshooting steps.** See [`troubleshooting.md`](troubleshooting.md) for
ServiceMonitor label mismatch, CRD ordering, pending LoadBalancer, and
missing-metric failure modes.

**Expected SRE handoff notes.**

- Read access details from `pulumi stack output` (Grafana URL, credentials,
  Prometheus service, namespaces, guestbook URL).
- Grafana password is recoverable only via `pulumi stack output
  grafanaAdminPassword --show-secrets`.
- No alerting yet — wire `GuestbookDown`, high error rate, high P95 latency, and
  pod crash-loop alerts as the next step.
- Storage is non-persistent by default — add a PVC and retention tuning before
  treating Prometheus data as durable.
