# Operations Runbook — Pulumi Kubernetes Guestbook Monitoring

Operational commands for deploying, checking rollout, and remediating the
Guestbook + Prometheus/Grafana stack. All commands assume the active kubeconfig
context points at the target cluster (`kubectl config current-context`) and that
you are in the project root.

Namespaces: `guestbook` (application) and `monitoring` (kube-prometheus-stack).

---

## 1. Deploy

```bash
# Install dependencies and initialise the stack (first time only)
npm install
pulumi stack init dev

# Configure the stack
pulumi config set appNamespace guestbook
pulumi config set monitoringNamespace monitoring
pulumi config set grafanaServiceType LoadBalancer      # NodePort for local clusters
pulumi config set grafanaAdminUser admin
pulumi config set --secret grafanaAdminPassword 'ChangeMe-Use-A-Secret'
pulumi config set cloudProvider aws                     # aws | gcp | azure | local

# Preview then apply
pulumi preview
pulumi up
```

Optional config:

```bash
pulumi config set prometheusChartVersion 65.1.1
pulumi config set enableNetworkPolicies true
pulumi config set enableDashboard true
```

Read access details after convergence:

```bash
pulumi stack output                                     # all outputs
pulumi stack output grafanaUrl
pulumi stack output guestbookFrontendUrl
pulumi stack output prometheusServiceName
pulumi stack output grafanaAdminPassword --show-secrets
```

Stack outputs available: `grafanaUrl`, `grafanaAdminUser`, `grafanaAdminPassword`
(secret), `prometheusServiceName`, `appNamespace`, `monitoringNamespace`,
`guestbookFrontendUrl`.

---

## 2. Rollout Checks

```bash
# Pods should be Running / Ready
kubectl get pods -n guestbook
kubectl get pods -n monitoring

# Services and exposure
kubectl get svc -n guestbook
kubectl get svc -n monitoring

# Operator CRDs and ServiceMonitor present
kubectl get crd | grep monitoring.coreos.com
kubectl get servicemonitor -A

# Deployment rollout status (wait for completion)
kubectl rollout status deployment/guestbook-frontend -n guestbook
kubectl rollout status deployment/redis-master -n guestbook
kubectl rollout status deployment/redis-replica -n guestbook

# Grafana external address (LoadBalancer)
kubectl get svc -n monitoring -o wide | grep -i grafana
```

Confirm scraping is live:

```bash
kubectl port-forward -n monitoring svc/prometheus-operated 9090:9090
# Browser → http://localhost:9090 → Status → Targets → guestbook target UP
# Query: up{namespace="guestbook"} == 1
```

Generate traffic and confirm counters move:

```bash
kubectl port-forward -n guestbook svc/guestbook-frontend 8080:80
# Browser → http://localhost:8080 → add a few entries
# Prometheus query: rate(guestbook_http_requests_total[5m]) > 0
```

---

## 3. Remediation

### Re-converge after a transient failure

```bash
pulumi refresh        # reconcile state with the live cluster
pulumi up             # re-apply desired state
```

### Restart a workload

```bash
kubectl rollout restart deployment/guestbook-frontend -n guestbook
kubectl rollout status  deployment/guestbook-frontend -n guestbook
```

### Inspect a failing pod

```bash
kubectl describe pod -n guestbook -l app.kubernetes.io/name=guestbook
kubectl logs -n guestbook -l app.kubernetes.io/name=guestbook --tail=100
kubectl get events -n guestbook --sort-by=.lastTimestamp | tail -n 20
```

### ServiceMonitor not producing a target

```bash
# Compare Service labels with ServiceMonitor selector — they must match
kubectl get svc -n guestbook --show-labels
kubectl get servicemonitor -n monitoring -o yaml | grep -A6 selector

# Confirm the metrics port is named and reachable
kubectl get svc guestbook-frontend -n guestbook -o jsonpath='{.spec.ports[*].name}'
```

See [`troubleshooting.md`](troubleshooting.md) for full remediation of each
failure mode.

### Grafana stuck without an external IP

```bash
kubectl get svc -n monitoring -o wide | grep -i grafana
# If EXTERNAL-IP is <pending> on a local cluster:
kubectl port-forward -n monitoring svc/<grafana-service> 3000:80
# or switch to NodePort:
pulumi config set grafanaServiceType NodePort && pulumi up
```

### Prometheus CRD ordering error during `pulumi up`

If `pulumi up` fails creating a `ServiceMonitor` because the CRD does not yet
exist, re-run `pulumi up` — the chart (which installs the CRDs) will have
completed on the first pass. The program is written to order the chart before the
ServiceMonitor; a repeat apply resolves any race on a cold cluster.

---

## 4. Rollback / Destroy

```bash
# Roll back to the previous Pulumi state version if a change regressed the stack
pulumi stack history
pulumi up    # re-apply known-good config after reverting source/config

# Tear everything down
pulumi destroy
pulumi stack rm dev
```

`pulumi destroy` removes the app, the monitoring stack, and chart-managed CRDs.
Confirm cleanup:

```bash
kubectl get ns guestbook monitoring        # should be terminating / not found
kubectl get crd | grep monitoring.coreos.com
```

---

## 5. SRE Handoff Notes

- Access details come from `pulumi stack output`; the Grafana password requires
  `--show-secrets`.
- Prometheus storage is non-persistent by default — do not treat metrics as
  durable until a PVC and retention are configured.
- No alert rules ship yet. Next-step alerts: `GuestbookDown`
  (`up{namespace="guestbook"} == 0`), high error rate, high P95 latency, pod
  crash-looping.
- For production: ingress + TLS + SSO/OIDC on Grafana, restricted source ranges,
  NetworkPolicies enabled, persistent Prometheus storage.
