# Troubleshooting — Pulumi Kubernetes Guestbook Monitoring

Common failure modes and their fixes for day-one operation. Namespaces:
`guestbook` and `monitoring`.

Start with the simple checks first: namespace, Service labels, ServiceMonitor
selector, and Prometheus target status. Most scrape failures are caused by one of
those four items.

---

## 1. ServiceMonitor created but no Prometheus target (label mismatch)

**Symptom.** The `ServiceMonitor` exists but Prometheus **Status → Targets** never
lists the Guestbook frontend; `up{namespace="guestbook"}` returns nothing.

**Cause.** The `ServiceMonitor` `spec.selector.matchLabels` does not match the
labels on the frontend Service. Prometheus Operator only scrapes Services whose
labels match the selector.

**Fix.**

```bash
# Show the Service labels
kubectl get svc guestbook-frontend -n guestbook --show-labels

# Show the ServiceMonitor selector
kubectl get servicemonitor -n monitoring -o yaml | grep -A6 'selector:'
```

The Service must carry the labels the selector requires, e.g.
`app.kubernetes.io/name: guestbook` and `app.kubernetes.io/component: frontend`.
Align them in `src/guestbook/frontend.ts` / `src/monitoring/service-monitors.ts`,
then `pulumi up`.

---

## 2. ServiceMonitor in the wrong namespace / missing namespaceSelector

**Symptom.** The ServiceMonitor and the Service are in different namespaces and the
target never appears.

**Cause.** The ServiceMonitor lives in `monitoring` but the frontend Service lives
in `guestbook`. Without a `namespaceSelector`, the operator only looks in the
ServiceMonitor's own namespace.

**Fix.** Ensure the ServiceMonitor sets:

```yaml
spec:
  namespaceSelector:
    matchNames:
      - guestbook
```

Confirm and re-apply:

```bash
kubectl get servicemonitor -n monitoring -o yaml | grep -A3 namespaceSelector
pulumi up
```

---

## 3. CRDs must exist before ServiceMonitor (CRD ordering)

**Symptom.** `pulumi up` fails creating the `ServiceMonitor` with an error like
"no matches for kind ServiceMonitor in version monitoring.coreos.com/v1".

**Cause.** The `monitoring.coreos.com` CRDs (installed by kube-prometheus-stack)
were not present when Pulumi tried to create the `ServiceMonitor` CR — a cold-start
ordering race.

**Fix.** The program orders the Helm chart (which installs the CRDs) before the
ServiceMonitor. If the race still occurs on a fresh cluster, simply re-run:

```bash
pulumi up
kubectl get crd | grep monitoring.coreos.com   # confirm CRDs now exist
```

---

## 4. Grafana LoadBalancer EXTERNAL-IP pending

**Symptom.** `kubectl get svc -n monitoring` shows the Grafana service `EXTERNAL-IP`
as `<pending>` indefinitely; `grafanaUrl` is not reachable.

**Cause.** The cluster has no cloud load-balancer controller — common on local
clusters (kind, minikube, Docker Desktop).

**Fix.** Use NodePort or port-forward:

```bash
# Option A: port-forward
kubectl port-forward -n monitoring svc/<grafana-service> 3000:80
# open http://localhost:3000

# Option B: switch service type
pulumi config set grafanaServiceType NodePort
pulumi up
kubectl get svc -n monitoring -o wide | grep -i grafana   # note the node port
```

> If EXTERNAL-IP is pending, use NodePort or `kubectl port-forward`. This is common
> on local clusters without a cloud load balancer implementation.

The same applies to the Guestbook frontend Service if it is a `LoadBalancer`.

---

## 5. Grafana deployed but not exposed / not reachable

**Symptom.** Grafana pods are running but there is no route to the UI.

**Cause.** Service type is `ClusterIP` (no external route) or the wrong service is
being addressed.

**Fix.**

```bash
kubectl get svc -n monitoring | grep -i grafana
kubectl port-forward -n monitoring svc/<grafana-service> 3000:80
```

For a routable address on a cloud cluster, set `grafanaServiceType LoadBalancer`
(or configure ingress) and `pulumi up`.

---

## 6. Only pod metrics, no application request metrics

**Symptom.** `container_cpu_usage_seconds_total` works but
`guestbook_http_requests_total` returns nothing.

**Cause.** The frontend `/metrics` endpoint is not being scraped — wrong port name,
wrong path, or the target is down. Application request metrics exist **only**
because the frontend is instrumented; they are not free from the base image.

**Fix.**

```bash
# The Service must expose a port named 'metrics'
kubectl get svc guestbook-frontend -n guestbook -o jsonpath='{.spec.ports[*].name}'

# Hit /metrics directly to confirm the app emits them
kubectl port-forward -n guestbook svc/guestbook-frontend 8080:80
curl -s http://localhost:8080/metrics | grep guestbook_http_requests_total
```

Confirm the ServiceMonitor endpoint uses `port: metrics` (or `http`) and
`path: /metrics`, the target is `UP` in Prometheus, then generate traffic so the
counters are non-zero.

---

## 7. Unnamed service ports

**Symptom.** ServiceMonitor cannot bind to a port; target never scrapes.

**Cause.** The ServiceMonitor references a port by name, but the Service port is
unnamed.

**Fix.** Give every relevant Service port a name (`http`, `metrics`) in
`src/guestbook/frontend.ts` and reference that name from the ServiceMonitor
endpoint. Re-apply with `pulumi up`.

---

## 8. Grafana login fails

**Symptom.** Cannot log into Grafana with the expected credentials.

**Cause.** Wrong password retrieved, or the password was never set.

**Fix.**

```bash
pulumi stack output grafanaAdminUser
pulumi stack output grafanaAdminPassword --show-secrets
```

If `grafanaAdminPassword` was never configured, set it and re-apply:

```bash
pulumi config set --secret grafanaAdminPassword 'ChangeMe-Use-A-Secret'
pulumi up
```

---

## 9. Dashboard panels empty

**Symptom.** The Guestbook Overview dashboard loads but panels show "No data".

**Cause.** No traffic has been generated yet, the Prometheus datasource is
misconfigured, or `enableDashboard` was false.

**Fix.**

```bash
# Confirm the dashboard is enabled
pulumi config get enableDashboard

# Confirm the datasource in Grafana → Connections → Data sources (Prometheus tests OK)
# Generate traffic, then check the panels
kubectl port-forward -n guestbook svc/guestbook-frontend 8080:80
# add entries at http://localhost:8080
```

---

## Quick reference

| Symptom | Cause | Fix |
|---------|-------|-----|
| No target in Prometheus | ServiceMonitor selector ≠ Service labels | Align labels, `pulumi up`. |
| Target in wrong namespace | Missing `namespaceSelector` | Add `namespaceSelector: matchNames: [guestbook]`. |
| `kind ServiceMonitor` error | CRDs not installed yet | Re-run `pulumi up`. |
| Grafana EXTERNAL-IP pending | No cloud LB controller | NodePort or `kubectl port-forward`. |
| Grafana unreachable | ClusterIP only | Set LoadBalancer/ingress or port-forward. |
| No app metrics | `/metrics` not scraped | Check `metrics` port name/path, target UP. |
| Login fails | Wrong/unset password | `pulumi stack output ... --show-secrets`. |
| Empty panels | No traffic / datasource | Generate traffic, verify datasource. |
