# Validation Notes

This project is intended for live Kubernetes validation rather than unit tests.

Recommended checks:

```powershell
npm run typecheck
pulumi preview
kubectl -n guestbook get pods
kubectl get servicemonitor -A
kubectl -n monitoring port-forward svc/prometheus-operated 9090:9090
```

In Prometheus, verify the `guestbook-frontend` target is `UP` and query:

```promql
guestbook_http_requests_total
rate(guestbook_http_requests_total[5m])
rate(guestbook_http_request_errors_total[5m])
```
