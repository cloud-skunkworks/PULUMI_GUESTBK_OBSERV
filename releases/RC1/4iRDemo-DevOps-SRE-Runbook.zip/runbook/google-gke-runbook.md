# Operations Runbook: Guestbook Monitoring on Google GKE

**Audience:** DevOps Engineers, SREs, Platform Engineers
**Target:** Google Kubernetes Engine (GKE)
**Grafana exposure:** `LoadBalancer` or port-forward fallback
**Last updated:** 2026-06-01

This runbook validates and operates an already-deployed Pulumi Guestbook monitoring stack on GKE. It does not create clusters, apply manifests, or run deployment commands.

## 1. Access Prerequisites

Required tools:

| Tool | Validation command |
|---|---|
| gcloud CLI | `gcloud version` |
| kubectl | `kubectl version --client` |
| jq | `jq --version` |
| curl | `curl --version` |

Configure kube access from an approved identity:

```bash
export GCP_PROJECT_ID=my-project
export GKE_LOCATION=us-central1
export GKE_CLUSTER_NAME=guestbook-monitoring-gke
gcloud auth list
gcloud config set project "$GCP_PROJECT_ID"
gcloud container clusters get-credentials "$GKE_CLUSTER_NAME" --region "$GKE_LOCATION" --project "$GCP_PROJECT_ID"
kubectl get nodes
```

Use workload identity or approved user authentication. Do not store service account JSON keys in the repository.

## 2. Validation

Run the GKE wrapper, then Prometheus and functional validation:

```bash
bash ./validation/validate-gcp.sh
bash ./validation/check-prometheus-targets.sh
bash ./validation/smoke-test.sh
```

PowerShell:

```powershell
pwsh ./validation/validate-gcp.ps1
pwsh ./validation/check-prometheus-targets.ps1
pwsh ./validation/smoke-test.ps1
```

Manual spot checks:

```bash
kubectl get ns guestbook monitoring
kubectl -n guestbook get pods -o wide
kubectl -n monitoring get pods
kubectl get servicemonitor -A
kubectl -n monitoring get svc
```

If Grafana has no external address, use a diagnostic port-forward:

```bash
kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80
```

## 3. Operations Notes

Daily checks:

```bash
kubectl get nodes
kubectl -n guestbook get pods
kubectl -n monitoring get pods
bash ./validation/validate-gcp.sh
```

Weekly checks:

```bash
kubectl -n monitoring get events --sort-by=.lastTimestamp
kubectl -n guestbook get events --sort-by=.lastTimestamp
kubectl -n monitoring get svc
gcloud compute forwarding-rules list --project "$GCP_PROJECT_ID"
```

Security controls:

| Control | Requirement |
|---|---|
| Credentials | Use Workload Identity Federation or approved user auth |
| Static keys | Do not store service account JSON keys in repo, scripts, or pipeline variables |
| Grafana exposure | Prefer internal load balancer or port-forward unless public exposure is explicitly approved |
| Namespace isolation | Keep `guestbook` and `monitoring` separate |
| Least privilege | Grant only required GKE and Kubernetes permissions |

## 4. Troubleshooting

Grafana external address missing:

```bash
kubectl -n monitoring get svc monitoring-grafana
kubectl -n monitoring describe svc monitoring-grafana
kubectl -n monitoring get events --sort-by=.lastTimestamp
```

Common causes:

| Cause | Resolution |
|---|---|
| Load balancer provisioning delay | Wait and re-check service events |
| Firewall or subnet issue | Review service events and VPC firewall rules |
| Regional/zone mismatch | Confirm the kube context points to the expected cluster |
| Quota issue | Review Google Cloud quota for forwarding rules and addresses |

ServiceMonitor target missing:

```bash
kubectl get servicemonitor -A
kubectl -n guestbook get svc --show-labels
kubectl -n guestbook get endpoints
```

The most common cause is a ServiceMonitor selector that does not match the Guestbook service labels.

## 5. Acceptance Criteria

| Requirement | Acceptance test | Status |
|---|---|---|
| Cluster reachable | `kubectl get nodes` succeeds | Pending |
| Guestbook deployed | `kubectl -n guestbook get pods` all Running | Pending |
| Monitoring deployed | Prometheus, Grafana, operator, kube-state-metrics Running | Pending |
| ServiceMonitor present | `kubectl get servicemonitor -A` shows Guestbook monitor | Pending |
| Target UP | `check-prometheus-targets.*` reports guestbook target UP | Pending |
| Functional traffic observable | `smoke-test.*` shows metric increase or records metric gap | Pending |

