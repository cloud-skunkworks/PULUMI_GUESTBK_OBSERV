# Operations Runbook: Guestbook Monitoring on Docker Desktop Kubernetes

**Runbook name:** Guestbook Kubernetes Monitoring — Docker Desktop (Local) Target
**Audience:** DevOps Engineers, SREs, Platform Engineers
**Target:** Docker Desktop built-in Kubernetes (local, single-node cluster)
**Technology scope:** Pulumi, Kubernetes, Helm, kube-prometheus-stack, Prometheus, Grafana, ServiceMonitor
**Grafana exposure:** `NodePort` + `kubectl port-forward` (LoadBalancer stays `<pending>` locally)
**Last updated:** 2026-06-01

> This is the **zero-cloud-cost** target. Use it to rehearse the entire runbook — deploy, validate, troubleshoot, teardown — before touching Azure AKS (`azure-aks-runbook.md`). The validation scripts in `validation/` are identical in spirit to the AKS path; only the exposure model differs.

---

## 1. TOGAF Architecture View (Docker Desktop)

| TOGAF View | Focus |
|---|---|
| Business Architecture | Local cluster lets SREs rehearse the runbook at no cloud cost and validate the scripts before a cloud deploy. No procurement or subscription approval needed. |
| Application Architecture | Same Guestbook frontend + Redis leader/replica in `guestbook`; frontend `/metrics` exposes `guestbook_http_requests_total`. kube-prometheus-stack in `monitoring` scrapes via `ServiceMonitor`. |
| Data Architecture | Prometheus time-series with labels `namespace`, `component`, `pod`. Ephemeral — data is lost on cluster reset. No persistent business data. |
| Technology Architecture | Single-node Kubernetes embedded in Docker Desktop. Pulumi (`cloudProvider=local`) applies the kube-prometheus-stack Helm chart. Grafana service type `NodePort` because there is no cloud LB provider. |
| Security Architecture | Grafana password still a Pulumi secret. Cluster is local-only, not internet-exposed. Namespaces separated. No secrets in Git. |
| Operations Architecture | Sections 4–11: enable K8s, configure, deploy, access via NodePort/port-forward, validate, teardown, troubleshoot. |

---

## 2. Prerequisites and Resource Sizing

### 2.1 Tools

| Tool | Purpose | Validation command |
|---|---|---|
| Docker Desktop | Provides the local Kubernetes cluster | `docker version` |
| Pulumi CLI | Deploy Kubernetes resources | `pulumi version` |
| Node.js LTS | Run the TypeScript Pulumi project | `node --version` |
| npm | Install project dependencies | `npm --version` |
| kubectl | Interact with the cluster (ships with Docker Desktop) | `kubectl version --client` |
| jq | Parse JSON in validation scripts | `jq --version` |

### 2.2 Resource sizing guidance

kube-prometheus-stack (Prometheus Operator + Prometheus + Grafana + kube-state-metrics + node-exporter) plus the Guestbook app is the heaviest part. Configure Docker Desktop with at least:

| Resource | Minimum | Recommended |
|---|---|---|
| CPUs | 4 vCPU | 6 vCPU |
| Memory | 6 GiB | 8 GiB |
| Disk | 20 GiB free | 40 GiB free |

Set these in **Docker Desktop → Settings → Resources**. If Prometheus or the operator stays `Pending` with `Insufficient cpu/memory`, raise the memory allocation first (Prometheus is memory-hungry).

---

## 3. Enable and Verify Kubernetes in Docker Desktop

### 3.1 Enable Kubernetes

1. Open **Docker Desktop → Settings → Kubernetes**.
2. Check **Enable Kubernetes**.
3. Click **Apply & Restart**. Docker Desktop provisions a single-node control plane (this takes a few minutes the first time).
4. Wait until the Kubernetes status indicator (bottom-left) is **green / running**.

### 3.2 Confirm the kube context is `docker-desktop`

```bash
kubectl config get-contexts
kubectl config use-context docker-desktop
kubectl config current-context     # must print: docker-desktop
```

```powershell
kubectl config use-context docker-desktop
kubectl config current-context
```

This is critical: if your context points at a cloud cluster you may accidentally deploy the local config (NodePort) to the wrong place. The `validate-docker-k8s` script hard-asserts the context equals `docker-desktop`.

### 3.3 Verify cluster access

```bash
kubectl get nodes              # one node, named docker-desktop, STATUS Ready
kubectl get namespaces
```

---

## 4. Pulumi Configuration (Local)

From the Pulumi project root after `npm install`:

```bash
pulumi stack select local || pulumi stack init local

pulumi config set cloudProvider local
pulumi config set appNamespace guestbook
pulumi config set monitoringNamespace monitoring
pulumi config set grafanaServiceType NodePort
pulumi config set grafanaAdminUser admin
pulumi config set --secret grafanaAdminPassword 'CHANGE-ME-STRONG-PASSWORD'
pulumi config set enableDashboard true
```

Why `NodePort` and not `LoadBalancer`:

> On Docker Desktop there is no cloud load-balancer provider, so a `LoadBalancer` service stays `EXTERNAL-IP: <pending>` forever. Use `NodePort` (reachable on `localhost`) or `kubectl port-forward`.

The Grafana admin password is still stored as an encrypted Pulumi secret — keep the same secure-defaults discipline even locally so the rehearsal matches the cloud path.

---

## 5. Deploy

```bash
pulumi preview
pulumi up
```

Review the preview for the `guestbook` and `monitoring` namespaces, Guestbook frontend + Redis leader/replica, the kube-prometheus-stack components, the `guestbook-frontend` ServiceMonitor, and the Grafana **NodePort** service.

On a single node, allow a few minutes for image pulls and for Prometheus to settle.

---

## 6. Expected Outputs

```bash
pulumi stack output
```

```text
appNamespace:          guestbook
monitoringNamespace:   monitoring
grafanaServiceType:    NodePort
grafanaAdminUser:      admin
grafanaAdminPassword:  [secret]
grafanaNodePort:       3xxxx
grafanaUrl:            http://localhost:3xxxx
grafanaAccessHint:     kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80
prometheusServiceName: prometheus-operated
guestbookFrontendService: guestbook-frontend
serviceMonitorName:    guestbook-frontend
```

---

## 7. Accessing Grafana and Guestbook (Local)

### 7.1 Via NodePort

Docker Desktop maps NodePorts to `localhost`, so the NodePort is directly reachable:

```bash
kubectl -n monitoring get svc monitoring-grafana
# read the PORT(S) column, e.g. 80:3xxxx/TCP  -> NodePort is 3xxxx
```

Open `http://localhost:<nodePort>` and log in with the Pulumi credentials:

```bash
pulumi stack output grafanaAdminUser
pulumi stack output grafanaAdminPassword --show-secrets
```

### 7.2 Via `kubectl port-forward` (always works)

If NodePort is blocked or you prefer a fixed local port:

```bash
# Grafana
kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80
# open http://localhost:3000

# Prometheus
kubectl -n monitoring port-forward svc/prometheus-operated 9090:9090
# open http://localhost:9090/targets

# Guestbook frontend (for traffic generation / metrics)
kubectl -n guestbook port-forward svc/guestbook-frontend 8080:80
# open http://localhost:8080
```

Keep the port-forward terminal open while accessing the service.

---

## 8. Validation

### 8.1 Automated (run the scripts)

```bash
# Local-specific wrapper: docker running, context == docker-desktop, Grafana NodePort, then core checks
bash ./validation/validate-docker-k8s.sh
# or, on Windows
pwsh ./validation/validate-docker-k8s.ps1

# Prometheus target health for the guestbook job
bash ./validation/check-prometheus-targets.sh

# End-to-end: traffic increases guestbook_http_requests_total
bash ./validation/smoke-test.sh
```

Each script exits non-zero on any failure. See `validation/VALIDATION-TESTS.md`.

### 8.2 Manual spot checks

```bash
kubectl get ns guestbook monitoring
kubectl -n guestbook get pods -o wide
kubectl -n monitoring get pods
kubectl get servicemonitor -A
kubectl get crd | grep monitoring.coreos.com
```

---

## 9. Routine Operations (Local Rehearsal)

Local ops are lighter than cloud, but rehearse the same gates:

```bash
kubectl get nodes
kubectl -n guestbook get pods
kubectl -n monitoring get pods
bash ./validation/validate-docker-k8s.sh
pulumi preview --diff             # rehearse drift detection
```

Use this environment to practice the AKS change-management and rollback flows safely before running them against cloud.

---

## 10. Teardown

```bash
pulumi stack select local
pulumi destroy
pulumi stack rm local       # optional
kubectl get ns guestbook monitoring     # expect NotFound
```

Full local reset (if the cluster gets into a bad state): **Docker Desktop → Settings → Kubernetes → Reset Kubernetes Cluster**. This wipes all workloads and is the fastest clean slate for the next rehearsal.

---

## 11. Local-Specific Troubleshooting

### 11.1 Grafana LoadBalancer stuck `<pending>`

Symptom: you set `grafanaServiceType=LoadBalancer` and `EXTERNAL-IP` never populates.

```bash
kubectl -n monitoring get svc monitoring-grafana
```

Cause: Docker Desktop has no cloud LB provider. Fix:

```bash
pulumi config set grafanaServiceType NodePort
pulumi up
# or just port-forward:
kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80
```

### 11.2 Pods Pending — insufficient resources

```bash
kubectl -n monitoring get pods
kubectl -n monitoring describe pod <pod-name> | grep -A5 Events
kubectl top nodes        # requires metrics-server
```

| Cause | Resolution |
|---|---|
| `Insufficient memory` | Raise Docker Desktop memory to 8 GiB (Settings → Resources) |
| `Insufficient cpu` | Raise CPUs to 4–6 |
| Disk pressure | Free disk or raise the Docker Desktop disk image size |

After raising resources, Apply & Restart, then re-check pod status.

### 11.3 ImagePullBackOff

```bash
kubectl -n guestbook describe pod <pod-name> | grep -A5 Events
```

| Cause | Resolution |
|---|---|
| No internet / proxy | Confirm Docker Desktop has network access; pull the image manually with `docker pull <image>` |
| Rate-limited registry | Authenticate to the registry or wait; consider mirroring |
| Wrong image tag | Fix the tag in Pulumi code and re-run `pulumi up` |

### 11.4 Context points at the wrong cluster

Symptom: `pulumi up` deploys somewhere unexpected, or `validate-docker-k8s` fails the context check.

```bash
kubectl config current-context
kubectl config use-context docker-desktop
kubectl config current-context     # must be docker-desktop
```

Always confirm the context is `docker-desktop` before `pulumi up` on this target.

### 11.5 Kubernetes won't start in Docker Desktop

1. Confirm Docker Desktop itself is running and healthy.
2. **Settings → Kubernetes → Reset Kubernetes Cluster**, then **Apply & Restart**.
3. As a last resort, restart Docker Desktop or the host.

---

## 12. Security Controls (Local)

| Control | Requirement |
|---|---|
| Grafana credentials | Still a Pulumi secret — keep cloud-equivalent discipline during rehearsal |
| Exposure | Cluster is local-only; NodePort binds to `localhost`, not the public internet |
| Namespaces | Keep `guestbook` and `monitoring` separated |
| Secrets in Git | Never commit decrypted Pulumi secrets or `.env` files |
| Cleanup | `pulumi destroy` or Reset Kubernetes Cluster removes all local state |

---

## 13. Local Acceptance Criteria

| Requirement | Acceptance test | Status |
|---|---|---|
| Kubernetes enabled | Docker Desktop K8s green; `kubectl get nodes` Ready | Pending |
| Correct context | `kubectl config current-context` == `docker-desktop` | Pending |
| Guestbook deployed | `kubectl -n guestbook get pods` all Running | Pending |
| Monitoring deployed | Prometheus, Grafana, operator, kube-state-metrics Running | Pending |
| ServiceMonitor present | `kubectl get servicemonitor -A` shows `guestbook-frontend` | Pending |
| Grafana reachable | NodePort on localhost or port-forward works | Pending |
| Target UP | `check-prometheus-targets.*` reports guestbook target `UP` | Pending |
| Traffic observable | `smoke-test.*` shows `guestbook_http_requests_total` increased | Pending |
| Teardown verified | `pulumi destroy` removes namespaces | Pending |
