#!/usr/bin/env bash
set -u

GUESTBOOK_NS="${GUESTBOOK_NS:-guestbook}"
MONITORING_NS="${MONITORING_NS:-monitoring}"
SERVICE_MONITOR_NAME="${SERVICE_MONITOR_NAME:-guestbook-frontend}"
FAILURES=0

pass() { printf 'PASS  %s\n' "$1"; }
warn() { printf 'WARN  %s\n' "$1"; }
fail() { printf 'FAIL  %s\n' "$1"; FAILURES=$((FAILURES + 1)); }
has_cmd() { command -v "$1" >/dev/null 2>&1; }

if ! has_cmd kubectl; then
  fail "kubectl is not installed or not on PATH"
  exit 1
fi
pass "kubectl is available"

if ! has_cmd jq; then
  fail "jq is required for JSON validation"
  exit 1
fi
pass "jq is available"

CONTEXT="$(kubectl config current-context 2>/dev/null || true)"
if [ -n "$CONTEXT" ]; then pass "current kube context: $CONTEXT"; else fail "no active kube context"; fi

if kubectl get nodes >/dev/null 2>&1; then pass "cluster API is reachable"; else fail "cluster API is not reachable with current context"; fi

for ns in "$GUESTBOOK_NS" "$MONITORING_NS"; do
  if kubectl get namespace "$ns" >/dev/null 2>&1; then pass "namespace exists: $ns"; else fail "namespace missing: $ns"; fi
done

for ns in "$GUESTBOOK_NS" "$MONITORING_NS"; do
  PODS="$(kubectl get pods -n "$ns" -o json 2>/dev/null || true)"
  COUNT="$(printf '%s' "$PODS" | jq '.items | length' 2>/dev/null || echo 0)"
  BAD="$(printf '%s' "$PODS" | jq -r '.items[]? | select(.status.phase != "Running" and .status.phase != "Succeeded") | .metadata.name' 2>/dev/null || true)"
  if [ "$COUNT" = "0" ]; then
    fail "no pods found in namespace $ns"
  elif [ -z "$BAD" ]; then
    pass "pods healthy in namespace $ns"
  else
    fail "pods not healthy in namespace $ns: $(printf '%s' "$BAD" | paste -sd ',' -)"
  fi
done

if kubectl get crd servicemonitors.monitoring.coreos.com >/dev/null 2>&1; then
  pass "ServiceMonitor CRD exists"
else
  fail "ServiceMonitor CRD missing; kube-prometheus-stack CRDs may not be installed"
fi

SMS="$(kubectl get servicemonitor -A -o json 2>/dev/null || true)"
SM_COUNT="$(printf '%s' "$SMS" | jq '.items | length' 2>/dev/null || echo 0)"
if [ "$SM_COUNT" = "0" ]; then
  fail "no ServiceMonitor resources found"
else
  pass "ServiceMonitor resources found: $SM_COUNT"
  if printf '%s' "$SMS" | jq -e --arg name "$SERVICE_MONITOR_NAME" --arg ns "$GUESTBOOK_NS" '.items[]? | select(.metadata.name == $name or .metadata.namespace == $ns)' >/dev/null; then
    pass "Guestbook ServiceMonitor found"
  else
    warn "no ServiceMonitor named '$SERVICE_MONITOR_NAME'; verify selector matches Guestbook services"
  fi
fi

SVC="$(kubectl get svc -n "$GUESTBOOK_NS" -o json 2>/dev/null || true)"
SVC_COUNT="$(printf '%s' "$SVC" | jq '.items | length' 2>/dev/null || echo 0)"
if [ "$SVC_COUNT" = "0" ]; then
  fail "no services found in namespace $GUESTBOOK_NS"
else
  pass "Guestbook services found: $(printf '%s' "$SVC" | jq -r '.items[].metadata.name' | paste -sd ',' -)"
fi

EPS="$(kubectl get endpoints -n "$GUESTBOOK_NS" -o json 2>/dev/null || true)"
if printf '%s' "$EPS" | jq -e '.items[]? | select(.subsets[]?.addresses[]?)' >/dev/null; then
  pass "Guestbook endpoints have ready addresses"
else
  fail "Guestbook endpoints have no ready addresses"
fi

MON_PODS="$(kubectl get pods -n "$MONITORING_NS" -o json 2>/dev/null || true)"
for needle in prometheus grafana operator; do
  if printf '%s' "$MON_PODS" | jq -e --arg needle "$needle" '.items[]? | select(.metadata.name | contains($needle))' >/dev/null; then
    pass "monitoring component present: $needle"
  else
    warn "monitoring component not obvious from pod names: $needle"
  fi
done

if [ "$FAILURES" -eq 0 ]; then
  printf 'SUMMARY PASS: core monitoring validation completed\n'
  exit 0
fi

printf 'SUMMARY FAIL: %s check(s) failed\n' "$FAILURES"
exit 1
