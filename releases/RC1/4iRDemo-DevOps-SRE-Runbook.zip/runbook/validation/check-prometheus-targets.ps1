param(
  [string]$MonitoringNamespace = "monitoring",
  [string]$PrometheusServiceName = "prometheus-operated",
  [int]$LocalPort = 9090,
  [string]$TargetPattern = "guestbook|frontend"
)

$ErrorActionPreference = "Stop"
$Failures = 0
function Pass($Message) { Write-Host "PASS  $Message" -ForegroundColor Green }
function Warn($Message) { Write-Host "WARN  $Message" -ForegroundColor Yellow }
function Fail($Message) { $script:Failures++; Write-Host "FAIL  $Message" -ForegroundColor Red }

$pf = $null
try {
  & kubectl -n $MonitoringNamespace get svc $PrometheusServiceName *> $null
  Pass "Prometheus service exists: $MonitoringNamespace/$PrometheusServiceName"

  $pf = Start-Process kubectl -ArgumentList @("-n", $MonitoringNamespace, "port-forward", "svc/$PrometheusServiceName", "${LocalPort}:9090") -WindowStyle Hidden -PassThru
  Start-Sleep -Seconds 4

  $targets = Invoke-RestMethod -Uri "http://127.0.0.1:$LocalPort/api/v1/targets" -TimeoutSec 15
  if ($targets.status -ne "success") {
    Fail "Prometheus targets API did not return success"
  } else {
    Pass "Prometheus targets API reachable"
    $active = @($targets.data.activeTargets)
    $guestbookTargets = @($active | Where-Object {
      (($_.labels.job -as [string]) -match $TargetPattern) -or
      (($_.labels.service -as [string]) -match $TargetPattern) -or
      (($_.labels.namespace -as [string]) -match "guestbook") -or
      (($_.scrapeUrl -as [string]) -match $TargetPattern)
    })
    if ($guestbookTargets.Count -eq 0) {
      Fail "no active Prometheus target matched pattern '$TargetPattern'"
    } else {
      $down = @($guestbookTargets | Where-Object { $_.health -ne "up" })
      if ($down.Count -eq 0) {
        Pass "matched Prometheus target(s) are UP: $($guestbookTargets.Count)"
      } else {
        Fail "matched Prometheus target(s) not UP: $($down | ForEach-Object { $_.scrapeUrl } | Join-String -Separator ', ')"
      }
    }
  }
} catch {
  Fail "Prometheus target validation failed: $($_.Exception.Message)"
} finally {
  if ($pf -and -not $pf.HasExited) {
    Stop-Process -Id $pf.Id -Force -ErrorAction SilentlyContinue
  }
}

if ($Failures -eq 0) { Write-Host "SUMMARY PASS: Prometheus target validation completed"; exit 0 }
Write-Host "SUMMARY FAIL: $Failures check(s) failed"
exit 1
