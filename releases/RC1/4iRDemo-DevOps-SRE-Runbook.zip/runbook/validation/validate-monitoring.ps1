param(
  [string]$GuestbookNamespace = "guestbook",
  [string]$MonitoringNamespace = "monitoring",
  [string]$ServiceMonitorName = "guestbook-frontend"
)

$ErrorActionPreference = "Stop"
$Failures = 0

function Pass($Message) { Write-Host "PASS  $Message" -ForegroundColor Green }
function Warn($Message) { Write-Host "WARN  $Message" -ForegroundColor Yellow }
function Fail($Message) { $script:Failures++; Write-Host "FAIL  $Message" -ForegroundColor Red }
function HasCommand($Name) { return $null -ne (Get-Command $Name -ErrorAction SilentlyContinue) }
function KubectlJson($ArgsList) {
  $raw = & kubectl @ArgsList -o json 2>$null
  if (-not $raw) { return $null }
  return $raw | ConvertFrom-Json
}

if (-not (HasCommand "kubectl")) {
  Fail "kubectl is not installed or not on PATH"
  exit 1
}
Pass "kubectl is available"

$context = (& kubectl config current-context 2>$null).Trim()
if ($context) { Pass "current kube context: $context" } else { Fail "no active kube context" }

try {
  & kubectl get nodes *> $null
  Pass "cluster API is reachable"
} catch {
  Fail "cluster API is not reachable with current context"
}

foreach ($ns in @($GuestbookNamespace, $MonitoringNamespace)) {
  try {
    & kubectl get namespace $ns *> $null
    Pass "namespace exists: $ns"
  } catch {
    Fail "namespace missing: $ns"
  }
}

foreach ($ns in @($GuestbookNamespace, $MonitoringNamespace)) {
  try {
    $pods = KubectlJson @("get", "pods", "-n", $ns)
    if (-not $pods -or -not $pods.items -or $pods.items.Count -eq 0) {
      Fail "no pods found in namespace $ns"
      continue
    }
    $bad = @($pods.items | Where-Object { $_.status.phase -ne "Running" -and $_.status.phase -ne "Succeeded" })
    if ($bad.Count -eq 0) {
      Pass "pods healthy in namespace $ns"
    } else {
      Fail "pods not healthy in namespace ${ns}: $($bad.metadata.name -join ', ')"
    }
  } catch {
    Fail "unable to inspect pods in namespace $ns"
  }
}

try {
  & kubectl get crd servicemonitors.monitoring.coreos.com *> $null
  Pass "ServiceMonitor CRD exists"
} catch {
  Fail "ServiceMonitor CRD missing; kube-prometheus-stack CRDs may not be installed"
}

try {
  $sms = KubectlJson @("get", "servicemonitor", "-A")
  if (-not $sms -or -not $sms.items -or $sms.items.Count -eq 0) {
    Fail "no ServiceMonitor resources found"
  } else {
    Pass "ServiceMonitor resources found: $($sms.items.Count)"
    $match = @($sms.items | Where-Object { $_.metadata.name -eq $ServiceMonitorName -or $_.metadata.namespace -eq $GuestbookNamespace })
    if ($match.Count -gt 0) {
      Pass "Guestbook ServiceMonitor found"
    } else {
      Warn "no ServiceMonitor named '$ServiceMonitorName'; verify selector matches Guestbook services"
    }
  }
} catch {
  Fail "unable to list ServiceMonitor resources"
}

try {
  $svc = KubectlJson @("get", "svc", "-n", $GuestbookNamespace)
  if ($svc -and $svc.items.Count -gt 0) {
    Pass "Guestbook services found: $($svc.items.metadata.name -join ', ')"
  } else {
    Fail "no services found in namespace $GuestbookNamespace"
  }
} catch {
  Fail "unable to inspect Guestbook services"
}

try {
  $endpoints = KubectlJson @("get", "endpoints", "-n", $GuestbookNamespace)
  $readyEndpoints = @($endpoints.items | Where-Object { $_.subsets -and $_.subsets.addresses })
  if ($readyEndpoints.Count -gt 0) {
    Pass "Guestbook endpoints have ready addresses"
  } else {
    Fail "Guestbook endpoints have no ready addresses"
  }
} catch {
  Fail "unable to inspect Guestbook endpoints"
}

try {
  $monPods = KubectlJson @("get", "pods", "-n", $MonitoringNamespace)
  $names = @($monPods.items.metadata.name)
  foreach ($needle in @("prometheus", "grafana", "operator")) {
    if (($names | Where-Object { $_ -like "*$needle*" }).Count -gt 0) {
      Pass "monitoring component present: $needle"
    } else {
      Warn "monitoring component not obvious from pod names: $needle"
    }
  }
} catch {
  Fail "unable to inspect monitoring components"
}

if ($Failures -eq 0) {
  Write-Host "SUMMARY PASS: core monitoring validation completed"
  exit 0
}

Write-Host "SUMMARY FAIL: $Failures check(s) failed"
exit 1
