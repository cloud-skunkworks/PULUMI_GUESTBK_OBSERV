#!/usr/bin/env bash
set -u

MONITORING_NS="${MONITORING_NS:-monitoring}"
PROMETHEUS_SERVICE_NAME="${PROMETHEUS_SERVICE_NAME:-prometheus-operated}"
LOCAL_PORT="${PROMETHEUS_LOCAL_PORT:-9090}"
TARGET_PATTERN="${TARGET_PATTERN:-guestbook|frontend}"
FAILURES=0
PF_PID=""

pass() { printf 'PASS  %s\n' "$1"; }
fail() { printf 'FAIL  %s\n' "$1"; FAILURES=$((FAILURES + 1)); }
cleanup() { if [ -n "$PF_PID" ]; then kill "$PF_PID" >/dev/null 2>&1 || true; fi; }
trap cleanup EXIT

if ! command -v jq >/dev/null 2>&1; then fail "jq is required"; exit 1; fi
if ! command -v curl >/dev/null 2>&1; then fail "curl is required"; exit 1; fi

if kubectl -n "$MONITORING_NS" get svc "$PROMETHEUS_SERVICE_NAME" >/dev/null 2>&1; then
  pass "Prometheus service exists: $MONITORING_NS/$PROMETHEUS_SERVICE_NAME"
else
  fail "Prometheus service missing: $MONITORING_NS/$PROMETHEUS_SERVICE_NAME"
  exit 1
fi

kubectl -n "$MONITORING_NS" port-forward "svc/$PROMETHEUS_SERVICE_NAME" "$LOCAL_PORT:9090" >/tmp/guestbook-prometheus-pf.log 2>&1 &
PF_PID=$!
sleep 4

TARGETS="$(curl -fsS "http://127.0.0.1:$LOCAL_PORT/api/v1/targets" 2>/dev/null || true)"
if [ -z "$TARGETS" ] || ! printf '%s' "$TARGETS" | jq -e '.status == "success"' >/dev/null; then
  fail "Prometheus targets API did not return success"
else
  pass "Prometheus targets API reachable"
  MATCHED="$(printf '%s' "$TARGETS" | jq --arg re "$TARGET_PATTERN" '[.data.activeTargets[]? | select((.labels.job // "" | test($re)) or (.labels.service // "" | test($re)) or (.labels.namespace // "" == "guestbook") or (.scrapeUrl // "" | test($re)))]')"
  MATCHED_COUNT="$(printf '%s' "$MATCHED" | jq 'length')"
  DOWN_COUNT="$(printf '%s' "$MATCHED" | jq '[.[] | select(.health != "up")] | length')"
  if [ "$MATCHED_COUNT" = "0" ]; then
    fail "no active Prometheus target matched pattern '$TARGET_PATTERN'"
  elif [ "$DOWN_COUNT" = "0" ]; then
    pass "matched Prometheus target(s) are UP: $MATCHED_COUNT"
  else
    fail "matched Prometheus target(s) not UP: $DOWN_COUNT"
  fi
fi

if [ "$FAILURES" -eq 0 ]; then
  printf 'SUMMARY PASS: Prometheus target validation completed\n'
  exit 0
fi
printf 'SUMMARY FAIL: %s check(s) failed\n' "$FAILURES"
exit 1
