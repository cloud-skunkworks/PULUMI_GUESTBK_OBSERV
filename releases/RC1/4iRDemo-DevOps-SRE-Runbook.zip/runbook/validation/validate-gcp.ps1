param(
  [string]$GuestbookNamespace = "guestbook",
  [string]$MonitoringNamespace = "monitoring",
  [string]$GrafanaServiceName = "kps-grafana",
  [string]$ExpectedClusterName = $env:GKE_CLUSTER_NAME
)

$ErrorActionPreference = "Stop"
$Failures = 0
function Pass($Message) { Write-Host "PASS  $Message" -ForegroundColor Green }
function Warn($Message) { Write-Host "WARN  $Message" -ForegroundColor Yellow }
function Fail($Message) { $script:Failures++; Write-Host "FAIL  $Message" -ForegroundColor Red }
function HasCommand($Name) { return $null -ne (Get-Command $Name -ErrorAction SilentlyContinue) }

if (HasCommand "gcloud") {
  try {
    $accounts = gcloud auth list --filter=status:ACTIVE --format="value(account)" 2>$null
    if ($accounts) { Pass "gcloud active account is available" } else { Fail "gcloud has no active authenticated account" }
  } catch {
    Fail "gcloud authentication check failed"
  }
} else {
  Fail "gcloud CLI is not installed or not on PATH"
}

$context = (& kubectl config current-context 2>$null).Trim()
if ($ExpectedClusterName) {
  if ($context -like "*$ExpectedClusterName*") { Pass "kube context matches GKE cluster hint: $ExpectedClusterName" } else { Warn "kube context '$context' does not include expected GKE name '$ExpectedClusterName'" }
} elseif ($context) {
  Pass "current kube context: $context"
} else {
  Fail "no active kube context"
}

try {
  $svc = & kubectl -n $MonitoringNamespace get svc $GrafanaServiceName -o json | ConvertFrom-Json
  if ($svc.spec.type -eq "LoadBalancer") { Pass "Grafana service type is LoadBalancer" } else { Warn "Grafana service type is $($svc.spec.type); GKE target normally uses LoadBalancer or internal LB" }
  $ingress = @($svc.status.loadBalancer.ingress)
  if ($ingress.Count -gt 0) { Pass "Grafana LoadBalancer ingress is assigned" } else { Warn "Grafana LoadBalancer ingress is pending; check service events and Google Cloud quotas" }
} catch {
  Fail "unable to inspect Grafana service $MonitoringNamespace/$GrafanaServiceName"
}

& "$PSScriptRoot\validate-monitoring.ps1" -GuestbookNamespace $GuestbookNamespace -MonitoringNamespace $MonitoringNamespace
$coreExit = $LASTEXITCODE

if ($Failures -eq 0 -and $coreExit -eq 0) { Write-Host "SUMMARY PASS: Google GKE validation completed"; exit 0 }
Write-Host "SUMMARY FAIL: Google GKE validation failed"
exit 1
