param(
  [string]$GuestbookNamespace = "guestbook",
  [string]$MonitoringNamespace = "monitoring",
  [string]$GrafanaServiceName = "kps-grafana",
  [string]$ExpectedClusterName = $env:EKS_CLUSTER_NAME
)

$ErrorActionPreference = "Stop"
$Failures = 0
function Pass($Message) { Write-Host "PASS  $Message" -ForegroundColor Green }
function Warn($Message) { Write-Host "WARN  $Message" -ForegroundColor Yellow }
function Fail($Message) { $script:Failures++; Write-Host "FAIL  $Message" -ForegroundColor Red }
function HasCommand($Name) { return $null -ne (Get-Command $Name -ErrorAction SilentlyContinue) }

if (HasCommand "aws") {
  try { aws sts get-caller-identity *> $null; Pass "AWS identity is available" } catch { Fail "AWS CLI is not authenticated or cannot call STS" }
} else {
  Fail "aws CLI is not installed or not on PATH"
}

$context = (& kubectl config current-context 2>$null).Trim()
if ($ExpectedClusterName) {
  if ($context -like "*$ExpectedClusterName*") { Pass "kube context matches EKS cluster hint: $ExpectedClusterName" } else { Warn "kube context '$context' does not include expected EKS name '$ExpectedClusterName'" }
} elseif ($context) {
  Pass "current kube context: $context"
} else {
  Fail "no active kube context"
}

try {
  $svc = & kubectl -n $MonitoringNamespace get svc $GrafanaServiceName -o json | ConvertFrom-Json
  if ($svc.spec.type -eq "LoadBalancer") { Pass "Grafana service type is LoadBalancer" } else { Warn "Grafana service type is $($svc.spec.type); EKS target normally uses LoadBalancer or internal LB" }
  $ingress = @($svc.status.loadBalancer.ingress)
  if ($ingress.Count -gt 0) { Pass "Grafana LoadBalancer ingress is assigned" } else { Warn "Grafana LoadBalancer ingress is pending; check EKS subnet tags and service events" }
} catch {
  Fail "unable to inspect Grafana service $MonitoringNamespace/$GrafanaServiceName"
}

& "$PSScriptRoot\validate-monitoring.ps1" -GuestbookNamespace $GuestbookNamespace -MonitoringNamespace $MonitoringNamespace
$coreExit = $LASTEXITCODE

if ($Failures -eq 0 -and $coreExit -eq 0) { Write-Host "SUMMARY PASS: Amazon EKS validation completed"; exit 0 }
Write-Host "SUMMARY FAIL: Amazon EKS validation failed"
exit 1
