#!/usr/bin/env bash
set -u

GUESTBOOK_NS="${GUESTBOOK_NS:-guestbook}"
MONITORING_NS="${MONITORING_NS:-monitoring}"
GRAFANA_SERVICE_NAME="${GRAFANA_SERVICE_NAME:-kps-grafana}"
EXPECTED_CLUSTER_NAME="${GKE_CLUSTER_NAME:-}"
FAILURES=0

pass() { printf 'PASS  %s\n' "$1"; }
warn() { printf 'WARN  %s\n' "$1"; }
fail() { printf 'FAIL  %s\n' "$1"; FAILURES=$((FAILURES + 1)); }

if command -v gcloud >/dev/null 2>&1 && [ -n "$(gcloud auth list --filter=status:ACTIVE --format='value(account)' 2>/dev/null)" ]; then pass "gcloud active account is available"; else fail "gcloud has no active authenticated account"; fi

CONTEXT="$(kubectl config current-context 2>/dev/null || true)"
if [ -n "$EXPECTED_CLUSTER_NAME" ]; then
  case "$CONTEXT" in *"$EXPECTED_CLUSTER_NAME"*) pass "kube context matches GKE cluster hint: $EXPECTED_CLUSTER_NAME" ;; *) warn "kube context '$CONTEXT' does not include expected GKE name '$EXPECTED_CLUSTER_NAME'" ;; esac
elif [ -n "$CONTEXT" ]; then
  pass "current kube context: $CONTEXT"
else
  fail "no active kube context"
fi

SVC="$(kubectl -n "$MONITORING_NS" get svc "$GRAFANA_SERVICE_NAME" -o json 2>/dev/null || true)"
TYPE="$(printf '%s' "$SVC" | jq -r '.spec.type // empty' 2>/dev/null || true)"
INGRESS_COUNT="$(printf '%s' "$SVC" | jq '.status.loadBalancer.ingress | length' 2>/dev/null || echo 0)"
if [ "$TYPE" = "LoadBalancer" ]; then pass "Grafana service type is LoadBalancer"; else warn "Grafana service type is ${TYPE:-unknown}; GKE target normally uses LoadBalancer or internal LB"; fi
if [ "$INGRESS_COUNT" -gt 0 ]; then pass "Grafana LoadBalancer ingress is assigned"; else warn "Grafana LoadBalancer ingress is pending; check service events and Google Cloud quotas"; fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GUESTBOOK_NS="$GUESTBOOK_NS" MONITORING_NS="$MONITORING_NS" bash "$SCRIPT_DIR/validate-monitoring.sh"
CORE_EXIT=$?

if [ "$FAILURES" -eq 0 ] && [ "$CORE_EXIT" -eq 0 ]; then
  printf 'SUMMARY PASS: Google GKE validation completed\n'
  exit 0
fi
printf 'SUMMARY FAIL: Google GKE validation failed\n'
exit 1
