param(
  [string]$GuestbookNamespace = "guestbook",
  [string]$MonitoringNamespace = "monitoring",
  [string]$FrontendServiceName = "guestbook-frontend",
  [string]$PrometheusServiceName = "prometheus-operated",
  [int]$FrontendLocalPort = 8080,
  [int]$PrometheusLocalPort = 9090,
  [string]$MetricName = "guestbook_http_requests_total",
  [switch]$AllowInfrastructureFallback
)

$ErrorActionPreference = "Stop"
$Failures = 0
function Pass($Message) { Write-Host "PASS  $Message" -ForegroundColor Green }
function Warn($Message) { Write-Host "WARN  $Message" -ForegroundColor Yellow }
function Fail($Message) { $script:Failures++; Write-Host "FAIL  $Message" -ForegroundColor Red }

function QueryProm($Query) {
  $encoded = [uri]::EscapeDataString($Query)
  return Invoke-RestMethod -Uri "http://127.0.0.1:$PrometheusLocalPort/api/v1/query?query=$encoded" -TimeoutSec 15
}

$pfFrontend = $null
$pfProm = $null
try {
  & kubectl -n $GuestbookNamespace get svc $FrontendServiceName *> $null
  & kubectl -n $MonitoringNamespace get svc $PrometheusServiceName *> $null
  Pass "frontend and Prometheus services exist"

  $pfFrontend = Start-Process kubectl -ArgumentList @("-n", $GuestbookNamespace, "port-forward", "svc/$FrontendServiceName", "${FrontendLocalPort}:80") -WindowStyle Hidden -PassThru
  $pfProm = Start-Process kubectl -ArgumentList @("-n", $MonitoringNamespace, "port-forward", "svc/$PrometheusServiceName", "${PrometheusLocalPort}:9090") -WindowStyle Hidden -PassThru
  Start-Sleep -Seconds 5

  $before = QueryProm "sum($MetricName)"
  $beforeValue = 0.0
  $hasMetric = $before.data.result.Count -gt 0
  if ($hasMetric) { $beforeValue = [double]$before.data.result[0].value[1] }

  for ($i = 0; $i -lt 10; $i++) {
    Invoke-WebRequest -Uri "http://127.0.0.1:$FrontendLocalPort/" -UseBasicParsing -TimeoutSec 10 *> $null
  }
  Pass "generated HTTP traffic against Guestbook frontend"

  Start-Sleep -Seconds 20
  $after = QueryProm "sum($MetricName)"
  if ($after.data.result.Count -gt 0) {
    $afterValue = [double]$after.data.result[0].value[1]
    if ($afterValue -gt $beforeValue) {
      Pass "$MetricName increased from $beforeValue to $afterValue"
    } else {
      Fail "$MetricName did not increase after frontend traffic (before=$beforeValue after=$afterValue)"
    }
  } else {
    $up = QueryProm 'sum(up{namespace="guestbook"})'
    if ($AllowInfrastructureFallback -and $up.data.result.Count -gt 0 -and [double]$up.data.result[0].value[1] -gt 0) {
      Warn "$MetricName is absent; infrastructure scrape is healthy. Document the application metrics gap."
      Pass "fallback infrastructure scrape for guestbook namespace is healthy"
    } else {
      Fail "$MetricName is absent. Do not claim application request metrics exist until instrumentation emits them."
    }
  }
} catch {
  Fail "smoke test failed: $($_.Exception.Message)"
} finally {
  foreach ($p in @($pfFrontend, $pfProm)) {
    if ($p -and -not $p.HasExited) { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue }
  }
}

if ($Failures -eq 0) { Write-Host "SUMMARY PASS: functional smoke test completed"; exit 0 }
Write-Host "SUMMARY FAIL: $Failures check(s) failed"
exit 1
