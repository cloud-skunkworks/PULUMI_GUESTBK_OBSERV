param(
  [string]$GuestbookNamespace = "guestbook",
  [string]$MonitoringNamespace = "monitoring",
  [string]$GrafanaServiceName = "kps-grafana"
)

$ErrorActionPreference = "Stop"
$Failures = 0
function Pass($Message) { Write-Host "PASS  $Message" -ForegroundColor Green }
function Warn($Message) { Write-Host "WARN  $Message" -ForegroundColor Yellow }
function Fail($Message) { $script:Failures++; Write-Host "FAIL  $Message" -ForegroundColor Red }
function HasCommand($Name) { return $null -ne (Get-Command $Name -ErrorAction SilentlyContinue) }

if (HasCommand "docker") {
  try { docker version *> $null; Pass "Docker engine is reachable" } catch { Fail "Docker engine is not reachable" }
} else {
  Fail "docker CLI is not installed or not on PATH"
}

$context = (& kubectl config current-context 2>$null).Trim()
if ($context -eq "docker-desktop") { Pass "kube context is docker-desktop" } else { Fail "expected kube context docker-desktop, got '$context'" }

try {
  $svc = & kubectl -n $MonitoringNamespace get svc $GrafanaServiceName -o json | ConvertFrom-Json
  if ($svc.spec.type -eq "NodePort") { Pass "Grafana service type is NodePort" } else { Warn "Grafana service type is $($svc.spec.type); local target normally uses NodePort" }
  $nodePorts = @($svc.spec.ports | Where-Object { $_.nodePort } | ForEach-Object { $_.nodePort })
  if ($nodePorts.Count -gt 0) { Pass "Grafana NodePort present: $($nodePorts -join ', ')" } else { Fail "Grafana service has no NodePort" }
} catch {
  Fail "unable to inspect Grafana service $MonitoringNamespace/$GrafanaServiceName"
}

& "$PSScriptRoot\validate-monitoring.ps1" -GuestbookNamespace $GuestbookNamespace -MonitoringNamespace $MonitoringNamespace
$coreExit = $LASTEXITCODE

if ($Failures -eq 0 -and $coreExit -eq 0) { Write-Host "SUMMARY PASS: Docker Desktop validation completed"; exit 0 }
Write-Host "SUMMARY FAIL: Docker Desktop validation failed"
exit 1
