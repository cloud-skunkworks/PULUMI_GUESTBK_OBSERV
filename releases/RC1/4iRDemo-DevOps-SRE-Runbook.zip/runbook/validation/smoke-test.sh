#!/usr/bin/env bash
set -u

GUESTBOOK_NS="${GUESTBOOK_NS:-guestbook}"
MONITORING_NS="${MONITORING_NS:-monitoring}"
FRONTEND_SERVICE_NAME="${FRONTEND_SERVICE_NAME:-guestbook-frontend}"
PROMETHEUS_SERVICE_NAME="${PROMETHEUS_SERVICE_NAME:-prometheus-operated}"
FRONTEND_LOCAL_PORT="${FRONTEND_LOCAL_PORT:-8080}"
PROMETHEUS_LOCAL_PORT="${PROMETHEUS_LOCAL_PORT:-9090}"
METRIC_NAME="${METRIC_NAME:-guestbook_http_requests_total}"
ALLOW_INFRASTRUCTURE_FALLBACK="${ALLOW_INFRASTRUCTURE_FALLBACK:-false}"
FAILURES=0
PF_FRONTEND=""
PF_PROM=""

pass() { printf 'PASS  %s\n' "$1"; }
warn() { printf 'WARN  %s\n' "$1"; }
fail() { printf 'FAIL  %s\n' "$1"; FAILURES=$((FAILURES + 1)); }
cleanup() {
  [ -n "$PF_FRONTEND" ] && kill "$PF_FRONTEND" >/dev/null 2>&1 || true
  [ -n "$PF_PROM" ] && kill "$PF_PROM" >/dev/null 2>&1 || true
}
trap cleanup EXIT

if ! command -v jq >/dev/null 2>&1; then fail "jq is required"; exit 1; fi
if ! command -v curl >/dev/null 2>&1; then fail "curl is required"; exit 1; fi

if kubectl -n "$GUESTBOOK_NS" get svc "$FRONTEND_SERVICE_NAME" >/dev/null 2>&1 && kubectl -n "$MONITORING_NS" get svc "$PROMETHEUS_SERVICE_NAME" >/dev/null 2>&1; then
  pass "frontend and Prometheus services exist"
else
  fail "frontend or Prometheus service is missing"
  exit 1
fi

kubectl -n "$GUESTBOOK_NS" port-forward "svc/$FRONTEND_SERVICE_NAME" "$FRONTEND_LOCAL_PORT:80" >/tmp/guestbook-frontend-pf.log 2>&1 &
PF_FRONTEND=$!
kubectl -n "$MONITORING_NS" port-forward "svc/$PROMETHEUS_SERVICE_NAME" "$PROMETHEUS_LOCAL_PORT:9090" >/tmp/guestbook-prometheus-pf.log 2>&1 &
PF_PROM=$!
sleep 5

prom_query() {
  local query="$1"
  curl -fsS --get --data-urlencode "query=$query" "http://127.0.0.1:$PROMETHEUS_LOCAL_PORT/api/v1/query" 2>/dev/null
}

BEFORE_JSON="$(prom_query "sum($METRIC_NAME)" || true)"
BEFORE_VALUE="$(printf '%s' "$BEFORE_JSON" | jq -r '.data.result[0].value[1] // "0"' 2>/dev/null || echo 0)"
HAS_METRIC="$(printf '%s' "$BEFORE_JSON" | jq -r '(.data.result | length) > 0' 2>/dev/null || echo false)"

for _ in 1 2 3 4 5 6 7 8 9 10; do
  curl -fsS "http://127.0.0.1:$FRONTEND_LOCAL_PORT/" >/dev/null 2>&1 || true
done
pass "generated HTTP traffic against Guestbook frontend"

sleep 20
AFTER_JSON="$(prom_query "sum($METRIC_NAME)" || true)"
AFTER_COUNT="$(printf '%s' "$AFTER_JSON" | jq -r '.data.result | length' 2>/dev/null || echo 0)"
AFTER_VALUE="$(printf '%s' "$AFTER_JSON" | jq -r '.data.result[0].value[1] // "0"' 2>/dev/null || echo 0)"

if [ "$AFTER_COUNT" -gt 0 ]; then
  if awk "BEGIN { exit !($AFTER_VALUE > $BEFORE_VALUE) }"; then
    pass "$METRIC_NAME increased from $BEFORE_VALUE to $AFTER_VALUE"
  else
    fail "$METRIC_NAME did not increase after frontend traffic (before=$BEFORE_VALUE after=$AFTER_VALUE)"
  fi
elif [ "$ALLOW_INFRASTRUCTURE_FALLBACK" = "true" ]; then
  UP_JSON="$(prom_query 'sum(up{namespace="guestbook"})' || true)"
  UP_VALUE="$(printf '%s' "$UP_JSON" | jq -r '.data.result[0].value[1] // "0"' 2>/dev/null || echo 0)"
  if awk "BEGIN { exit !($UP_VALUE > 0) }"; then
    warn "$METRIC_NAME is absent; infrastructure scrape is healthy. Document the application metrics gap."
    pass "fallback infrastructure scrape for guestbook namespace is healthy"
  else
    fail "$METRIC_NAME is absent and fallback infrastructure scrape did not validate"
  fi
else
  fail "$METRIC_NAME is absent. Do not claim application request metrics exist until instrumentation emits them."
fi

if [ "$FAILURES" -eq 0 ]; then
  printf 'SUMMARY PASS: functional smoke test completed\n'
  exit 0
fi
printf 'SUMMARY FAIL: %s check(s) failed\n' "$FAILURES"
exit 1
