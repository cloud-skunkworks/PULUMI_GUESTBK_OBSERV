# Validation Test Reference

These scripts are read-only validation helpers. They do not run deployment,
destroy, manifest apply, or cloud resource creation commands.

## Core Health

PowerShell:

```powershell
pwsh ./validation/validate-monitoring.ps1
```

Bash:

```bash
bash ./validation/validate-monitoring.sh
```

Checks:

- `kubectl` is present and can reach the current cluster.
- `guestbook` and `monitoring` namespaces exist.
- Pods are `Running` or `Succeeded`.
- `ServiceMonitor` CRD exists.
- A Guestbook ServiceMonitor is present.
- Guestbook services and endpoints have ready addresses.

## Target Wrappers

Use one wrapper for the active environment:

```powershell
pwsh ./validation/validate-docker-k8s.ps1
pwsh ./validation/validate-azure.ps1
pwsh ./validation/validate-aws.ps1
pwsh ./validation/validate-gcp.ps1
```

```bash
bash ./validation/validate-docker-k8s.sh
bash ./validation/validate-azure.sh
bash ./validation/validate-aws.sh
bash ./validation/validate-gcp.sh
```

Each wrapper checks the relevant cloud or local CLI context, then calls the
cloud-neutral monitoring validation.

## Prometheus Target Validation

PowerShell:

```powershell
pwsh ./validation/check-prometheus-targets.ps1
```

Bash:

```bash
bash ./validation/check-prometheus-targets.sh
```

Default service names:

- Frontend service: `frontend`
- Prometheus service: `prometheus-operated`
- Monitoring namespace: `monitoring`

The script port-forwards Prometheus, calls `/api/v1/targets`, and fails if the
Guestbook target is absent or not `UP`.

## End-to-End Smoke Test

PowerShell:

```powershell
pwsh ./validation/smoke-test.ps1
```

Bash:

```bash
bash ./validation/smoke-test.sh
```

The smoke test:

1. Port-forwards the frontend service and Prometheus service.
2. Reads the current `guestbook_http_requests_total` value.
3. Sends traffic to the frontend.
4. Confirms the metric increases after Prometheus scrapes again.

## Parameters

PowerShell scripts accept explicit parameters:

```powershell
pwsh ./validation/smoke-test.ps1 `
  -GuestbookNamespace guestbook `
  -MonitoringNamespace monitoring `
  -FrontendServiceName frontend `
  -PrometheusServiceName prometheus-operated
```

Bash scripts use environment variables:

```bash
GUESTBOOK_NS=guestbook \
MONITORING_NS=monitoring \
FRONTEND_SERVICE_NAME=guestbook-frontend \
PROMETHEUS_SERVICE_NAME=prometheus-operated \
bash ./validation/smoke-test.sh
```

If the generated implementation uses `guestbook-frontend` or
another service name, override the defaults with the parameters above. Do not
edit the scripts just to change service names.

## Results Table

| Date | Operator | Cluster | Script | Result | Notes |
|---|---|---|---|---|---|
|  |  |  | validate-monitoring |  |  |
|  |  |  | check-prometheus-targets |  |  |
|  |  |  | smoke-test |  |  |
