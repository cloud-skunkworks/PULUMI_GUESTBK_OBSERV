param(
  [string]$GuestbookNamespace = "guestbook",
  [string]$MonitoringNamespace = "monitoring",
  [string]$GrafanaServiceName = "kps-grafana",
  [string]$ExpectedClusterName = $env:AKS_CLUSTER_NAME
)

$ErrorActionPreference = "Stop"
$Failures = 0
function Pass($Message) { Write-Host "PASS  $Message" -ForegroundColor Green }
function Warn($Message) { Write-Host "WARN  $Message" -ForegroundColor Yellow }
function Fail($Message) { $script:Failures++; Write-Host "FAIL  $Message" -ForegroundColor Red }
function HasCommand($Name) { return $null -ne (Get-Command $Name -ErrorAction SilentlyContinue) }

if (HasCommand "az") {
  try { az account show *> $null; Pass "Azure CLI authenticated account is available" } catch { Fail "Azure CLI is not logged in or subscription is unavailable" }
} else {
  Fail "az CLI is not installed or not on PATH"
}

$context = (& kubectl config current-context 2>$null).Trim()
if ($ExpectedClusterName) {
  if ($context -like "*$ExpectedClusterName*") { Pass "kube context matches AKS cluster hint: $ExpectedClusterName" } else { Warn "kube context '$context' does not include expected AKS name '$ExpectedClusterName'" }
} elseif ($context) {
  Pass "current kube context: $context"
} else {
  Fail "no active kube context"
}

try {
  $svc = & kubectl -n $MonitoringNamespace get svc $GrafanaServiceName -o json | ConvertFrom-Json
  if ($svc.spec.type -eq "LoadBalancer") { Pass "Grafana service type is LoadBalancer" } else { Warn "Grafana service type is $($svc.spec.type); AKS target normally uses LoadBalancer or internal LB" }
  $ingress = @($svc.status.loadBalancer.ingress)
  if ($ingress.Count -gt 0) { Pass "Grafana LoadBalancer ingress is assigned" } else { Warn "Grafana LoadBalancer ingress is pending; use port-forward while investigating" }
} catch {
  Fail "unable to inspect Grafana service $MonitoringNamespace/$GrafanaServiceName"
}

& "$PSScriptRoot\validate-monitoring.ps1" -GuestbookNamespace $GuestbookNamespace -MonitoringNamespace $MonitoringNamespace
$coreExit = $LASTEXITCODE

if ($Failures -eq 0 -and $coreExit -eq 0) { Write-Host "SUMMARY PASS: Azure AKS validation completed"; exit 0 }
Write-Host "SUMMARY FAIL: Azure AKS validation failed"
exit 1
