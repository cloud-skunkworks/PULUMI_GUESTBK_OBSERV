# Function Validation Checklist

Use this checklist after a deployment has completed through the approved pipeline
or Pulumi workflow. The checklist itself is validation-only: do not deploy,
apply manifests, delete resources, or print secrets while completing it.

## 1. Cluster and Namespace Health

- [ ] `kubectl config current-context` points at the intended cluster.
- [ ] `guestbook` namespace exists.
- [ ] `monitoring` namespace exists.
- [ ] Guestbook frontend, Redis master, and Redis replica pods are `Running`.
- [ ] Prometheus, Grafana, and Prometheus Operator pods are `Running`.

## 2. Prometheus Scrape Validation

- [ ] `kubectl get crd servicemonitors.monitoring.coreos.com` succeeds.
- [ ] `kubectl get servicemonitor -A` shows `monitoring/guestbook-frontend`.
- [ ] `validation/check-prometheus-targets.*` reports matched target(s) are `UP`.
- [ ] Prometheus query returns data: `guestbook_http_requests_total`.
- [ ] Prometheus query returns data after traffic: `rate(guestbook_http_requests_total[5m])`.

## 3. Functional Traffic Validation

- [ ] `validation/smoke-test.*` can port-forward the frontend and Prometheus services.
- [ ] Smoke test generates HTTP requests against the frontend.
- [ ] `guestbook_http_requests_total` increases after generated traffic.
- [ ] Optional `/error` test increases `guestbook_http_request_errors_total`.

## 4. Grafana Validation

- [ ] `pulumi stack output grafanaUrl` returns a usable access path or port-forward hint.
- [ ] Grafana login works with `grafanaAdminUser` and secret password from Pulumi.
- [ ] `Guestbook Monitoring` dashboard is present.
- [ ] Request rate, error rate, latency, CPU, memory, and restart panels render data.

## 5. Security and Handoff

- [ ] No Grafana password, API key, kubeconfig, or `.env` value is committed.
- [ ] Public Grafana exposure has explicit approval, or access uses port-forward/internal LB.
- [ ] Namespaces remain separated: app in `guestbook`, monitoring in `monitoring`.
- [ ] Any cluster-scoped Prometheus Operator permissions are documented for implementation approvers.
- [ ] Rollback/decommission path is documented for the target environment.

## 6. Target-Specific Wrapper

- [ ] Local: `validation/validate-docker-k8s.*` passes for Docker Desktop.
- [ ] AKS: `validation/validate-azure.*` passes for Azure Kubernetes Service.
- [ ] EKS: `validation/validate-aws.*` passes for Amazon EKS.
- [ ] GKE: `validation/validate-gcp.*` passes for Google GKE.
