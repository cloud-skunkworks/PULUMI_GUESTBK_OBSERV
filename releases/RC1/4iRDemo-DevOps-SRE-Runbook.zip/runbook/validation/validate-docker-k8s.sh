#!/usr/bin/env bash
set -u

GUESTBOOK_NS="${GUESTBOOK_NS:-guestbook}"
MONITORING_NS="${MONITORING_NS:-monitoring}"
GRAFANA_SERVICE_NAME="${GRAFANA_SERVICE_NAME:-kps-grafana}"
FAILURES=0

pass() { printf 'PASS  %s\n' "$1"; }
warn() { printf 'WARN  %s\n' "$1"; }
fail() { printf 'FAIL  %s\n' "$1"; FAILURES=$((FAILURES + 1)); }

if command -v docker >/dev/null 2>&1 && docker version >/dev/null 2>&1; then pass "Docker engine is reachable"; else fail "Docker engine is not reachable"; fi

CONTEXT="$(kubectl config current-context 2>/dev/null || true)"
if [ "$CONTEXT" = "docker-desktop" ]; then pass "kube context is docker-desktop"; else fail "expected kube context docker-desktop, got '$CONTEXT'"; fi

SVC="$(kubectl -n "$MONITORING_NS" get svc "$GRAFANA_SERVICE_NAME" -o json 2>/dev/null || true)"
TYPE="$(printf '%s' "$SVC" | jq -r '.spec.type // empty' 2>/dev/null || true)"
NODEPORTS="$(printf '%s' "$SVC" | jq -r '.spec.ports[]? | select(.nodePort) | .nodePort' 2>/dev/null || true)"
if [ "$TYPE" = "NodePort" ]; then pass "Grafana service type is NodePort"; else warn "Grafana service type is ${TYPE:-unknown}; local target normally uses NodePort"; fi
if [ -n "$NODEPORTS" ]; then pass "Grafana NodePort present: $(printf '%s' "$NODEPORTS" | paste -sd ',' -)"; else fail "Grafana service has no NodePort"; fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GUESTBOOK_NS="$GUESTBOOK_NS" MONITORING_NS="$MONITORING_NS" bash "$SCRIPT_DIR/validate-monitoring.sh"
CORE_EXIT=$?

if [ "$FAILURES" -eq 0 ] && [ "$CORE_EXIT" -eq 0 ]; then
  printf 'SUMMARY PASS: Docker Desktop validation completed\n'
  exit 0
fi
printf 'SUMMARY FAIL: Docker Desktop validation failed\n'
exit 1
