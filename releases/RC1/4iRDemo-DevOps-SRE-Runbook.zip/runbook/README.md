# Guestbook Monitoring Runbook Package

**Package name:** Guestbook Kubernetes Monitoring Runbook
**Audience:** DevOps Engineers, SREs, Platform Engineers, Cloud Operations Leads, IT Managers
**Deployment scope:** Local Kubernetes, Azure AKS, Amazon EKS, and Google GKE
**Technology scope:** Pulumi, Kubernetes, Helm, kube-prometheus-stack, Prometheus, Grafana, ServiceMonitor
**Application scope:** Pulumi Kubernetes Guestbook (frontend + Redis leader/replica) extended with Prometheus and Grafana monitoring
**Operational maturity target:** Lab, proof of concept, controlled non-production, and SRE rehearsal
**Last updated:** 2026-06-01

---

## 1. Purpose and Scope

This is a **standalone operations runbook package** for validating, operating, and decommissioning the monitored Guestbook application on four Kubernetes targets:

1. **Docker Desktop Kubernetes** — the local, single-node, zero-cloud-cost rehearsal target.
2. **Azure AKS** — managed Azure Kubernetes target.
3. **Amazon EKS** — managed AWS Kubernetes target.
4. **Google GKE** — managed Google Cloud Kubernetes target.

The implementation under operation is the kube-prometheus-stack-based Pulumi project described in `DEVOPS-SRE-K8S-MONITORING-SKILL.md`. These runbooks assume deployment has already been performed through Pulumi. The validation scripts do not run `pulumi up`, `kubectl apply`, or cloud create/delete commands.

The centerpiece of this package is the **`validation/` directory of runnable test scripts**. Operations personnel execute these to prove the deployment is healthy on either target.

---

## 2. Audience and Roles

| Role | Responsibilities in this package |
|---|---|
| IT Manager | Approves Azure subscription, cost envelope (LoadBalancer + nodes), access model, acceptance criteria |
| Platform Lead | Owns cluster standards, RBAC, namespace patterns, production-readiness gate |
| DevOps / SRE Engineer | Executes deploy on AKS or Docker Desktop, runs validation scripts, documents results |
| Security Engineer | Reviews Pulumi secrets, Grafana public exposure, internal LB / private cluster posture |
| Application Owner | Confirms Guestbook functionality and `guestbook_http_requests_total` metric flow |

---

## 3. Package Contents (Index)

| File | Purpose |
|---|---|
| `README.md` | This file — overview, scope, TOGAF view, index, how to run validation |
| `OBSERVABILITY-SOLUTION-WIKI.md` | Blog/wiki explainer for junior Azure DevOps SREs: what the solution does, how it works, and how to productionize it |
| `azure-aks-runbook.md` | AKS lifecycle and validation |
| `aws-eks-runbook.md` | EKS access, validation, operations, troubleshooting, and acceptance checklist |
| `google-gke-runbook.md` | GKE access, validation, operations, troubleshooting, and acceptance checklist |
| `docker-desktop-k8s-runbook.md` | Local Docker Desktop Kubernetes lifecycle and validation |
| `validation/validate-monitoring.ps1` / `.sh` | Cloud-neutral core checks (context, namespaces, pods, ServiceMonitor, CRD) |
| `validation/validate-azure.ps1` / `.sh` | Azure-specific checks (`az account`, AKS context, Grafana EXTERNAL-IP) then core checks |
| `validation/validate-aws.ps1` / `.sh` | AWS-specific checks (`aws sts`, EKS context hint, Grafana LoadBalancer) then core checks |
| `validation/validate-gcp.ps1` / `.sh` | GCP-specific checks (`gcloud auth`, GKE context hint, Grafana LoadBalancer) then core checks |
| `validation/validate-docker-k8s.ps1` / `.sh` | Local checks (docker running, `docker-desktop` context, NodePort) then core checks |
| `validation/check-prometheus-targets.ps1` / `.sh` | Asserts guestbook Prometheus target health is `UP` via `/api/v1/targets` |
| `validation/smoke-test.ps1` / `.sh` | End-to-end: generate traffic, assert `guestbook_http_requests_total` increased |
| `validation/FUNCTION-VALIDATION-CHECKLIST.md` | Operator checklist for target health, Prometheus scrape health, Grafana access, and functional traffic validation |
| `validation/VALIDATION-TESTS.md` | Documents every script: purpose, prerequisites, how to run (PowerShell + bash), checks, expected output, pass/fail criteria, results table |

---

## 4. TOGAF Architecture View

This package is structured for auditability using TOGAF-style domains. Each runbook repeats this lens for its specific target.

| TOGAF View | Focus in this package |
|---|---|
| Business Architecture | Why each target exists: Docker Desktop for zero-cost rehearsal, AKS/EKS/GKE for managed-cloud validation; who owns each; acceptance criteria |
| Application Architecture | Guestbook frontend + Redis leader/replica; `/metrics` endpoint exposing `guestbook_http_requests_total`; ServiceMonitor scrape flow; Grafana dashboard |
| Data Architecture | Prometheus time-series metrics, labels (`namespace`, `component`, `pod`), retention, Grafana query path; no business data beyond sample Guestbook state |
| Technology Architecture | Kubernetes (AKS managed vs Docker Desktop single-node), Pulumi deployment, kube-prometheus-stack Helm chart, Grafana exposure (LoadBalancer vs NodePort) |
| Security Architecture | Pulumi secret for Grafana password, namespace separation, avoid public Grafana, internal LB / private cluster on AKS, no committed secrets |
| Operations Architecture | Install, validate (the scripts), routine ops, change management, rollback, decommission, troubleshooting per target |

---

## 5. Deployment Targets at a Glance

| Attribute | Docker Desktop Kubernetes | Azure AKS | Amazon EKS | Google GKE |
|---|---|---|---|---|
| Cluster type | Local single-node | Managed multi-node | Managed multi-node | Managed multi-node |
| Kube context | `docker-desktop` | AKS context from `az aks get-credentials` | EKS context from `aws eks update-kubeconfig` | GKE context from `gcloud container clusters get-credentials` |
| `cloudProvider` Pulumi config | `local` | `azure` | `aws` | `gcp` |
| `grafanaServiceType` | `NodePort` | `LoadBalancer` | `LoadBalancer` | `LoadBalancer` |
| Grafana access | NodePort on `localhost` + `kubectl port-forward` | Azure LB IP or port-forward | AWS ELB/NLB DNS or port-forward | Google Cloud LB IP or port-forward |
| Cost | Zero cloud cost | Nodes, LB, public IP, disks, log ingestion | Nodes/Fargate, LB, disks, logging | Nodes/Autopilot, LB, disks, logging |
| Primary validation script | `validate-docker-k8s.*` | `validate-azure.*` | `validate-aws.*` | `validate-gcp.*` |
| Cleanup | `pulumi destroy` | `pulumi destroy` + optional resource group cleanup | `pulumi destroy` + optional cluster cleanup | `pulumi destroy` + optional cluster cleanup |

---

## 6. Expected Pulumi Outputs

Both targets share the same Pulumi program and emit these outputs (referenced by the validation scripts):

```text
appNamespace:          guestbook
monitoringNamespace:   monitoring
grafanaServiceType:    LoadBalancer | NodePort
grafanaAdminUser:      admin
grafanaAdminPassword:  [secret]
grafanaUrl:            http://<external-ip>:3000   (AKS)  |  http://localhost:<nodePort>  (local)
prometheusServiceName: prometheus-operated
guestbookFrontendService: guestbook-frontend
serviceMonitorName:    guestbook-frontend
```

Retrieve any output with:

```bash
pulumi stack output <name>
pulumi stack output grafanaAdminPassword --show-secrets
```

---

## 7. How to Run the Validation Tests

All scripts live in `validation/`. They depend on `kubectl` and (for some) `jq`, `az`, `docker`, and `curl`/`Invoke-RestMethod`. Every script prints `PASS` / `FAIL` per check, accumulates failures, and exits non-zero if any check fails — suitable for CI gates.

### 7.1 Recommended order

1. **Core health** (works on either target):
   - Windows: `pwsh ./validation/validate-monitoring.ps1`
   - bash: `bash ./validation/validate-monitoring.sh`
2. **Target-specific wrapper** (runs target checks then the core checks):
   - AKS — `pwsh ./validation/validate-azure.ps1` or `bash ./validation/validate-azure.sh`
   - EKS — `pwsh ./validation/validate-aws.ps1` or `bash ./validation/validate-aws.sh`
   - GKE — `pwsh ./validation/validate-gcp.ps1` or `bash ./validation/validate-gcp.sh`
   - Docker Desktop — `pwsh ./validation/validate-docker-k8s.ps1` or `bash ./validation/validate-docker-k8s.sh`
3. **Prometheus target health**:
   - `pwsh ./validation/check-prometheus-targets.ps1` or `bash ./validation/check-prometheus-targets.sh`
4. **End-to-end smoke test**:
   - `pwsh ./validation/smoke-test.ps1` or `bash ./validation/smoke-test.sh`

### 7.2 Parameterization

PowerShell scripts accept `-GuestbookNamespace`, `-MonitoringNamespace`, and service-name params. Bash scripts read the equivalent environment variables (`GUESTBOOK_NS`, `MONITORING_NS`, etc.) with safe defaults of `guestbook` and `monitoring`.

```powershell
pwsh ./validation/validate-monitoring.ps1 -GuestbookNamespace guestbook -MonitoringNamespace monitoring
```

```bash
GUESTBOOK_NS=guestbook MONITORING_NS=monitoring bash ./validation/validate-monitoring.sh
```

### 7.3 Interpreting results

- Exit code `0` = all checks passed.
- Exit code `1` = at least one `FAIL` (the summary line lists the count).
- `WARN` lines (e.g., LoadBalancer still pending on AKS) do not fail the run but give an actionable hint (usually a `kubectl port-forward` command).

Full per-check documentation is in `validation/VALIDATION-TESTS.md`. Use `validation/FUNCTION-VALIDATION-CHECKLIST.md` as the operator handoff sheet.

---

## 8. Security Summary (applies to both targets)

| Control | Requirement |
|---|---|
| Grafana credentials | Store as Pulumi secret (`pulumi config set --secret grafanaAdminPassword`), never plaintext or committed |
| Public exposure | Avoid public Grafana on AKS unless explicitly approved; prefer internal LB or port-forward |
| Namespaces | Keep `guestbook` and `monitoring` separated |
| Secrets in Git | Never commit `Pulumi.<stack>.yaml` secret values or `.env` files |
| Least privilege | Scoped platform-admin where practical; cluster-admin only for Operator CRD install in lab |
| Audit | Record stack, commit SHA, operator, cluster, and timestamp on handoff |

---

## 9. References

1. `docker-desktop-k8s-runbook.md` — Docker Desktop Kubernetes lifecycle.
2. `azure-aks-runbook.md` — Azure AKS lifecycle.
3. `aws-eks-runbook.md` — Amazon EKS lifecycle.
4. `google-gke-runbook.md` — Google GKE lifecycle.
5. `validation/VALIDATION-TESTS.md` — script documentation and results table.
6. `validation/FUNCTION-VALIDATION-CHECKLIST.md` — operator handoff checklist.
7. `DEVOPS-SRE-K8S-MONITORING-SKILL.md` — implementation spec (kube-prometheus-stack, ServiceMonitor, metrics).
8. `DEVOPS-SRE-K8S-MONITORING-RUNBOOK.md` — source operations runbook.
