# Operations Runbook: Guestbook Monitoring on Amazon EKS

**Audience:** DevOps Engineers, SREs, Platform Engineers
**Target:** Amazon Elastic Kubernetes Service (EKS)
**Grafana exposure:** `LoadBalancer` or port-forward fallback
**Last updated:** 2026-06-01

This runbook validates and operates an already-deployed Pulumi Guestbook monitoring stack on EKS. It does not create clusters, apply manifests, or run deployment commands.

## 1. Access Prerequisites

Required tools:

| Tool | Validation command |
|---|---|
| AWS CLI | `aws --version` |
| kubectl | `kubectl version --client` |
| jq | `jq --version` |
| curl | `curl --version` |

Configure kube access from an approved identity:

```bash
export AWS_REGION=us-east-1
export EKS_CLUSTER_NAME=guestbook-monitoring-eks
aws sts get-caller-identity
aws eks update-kubeconfig --region "$AWS_REGION" --name "$EKS_CLUSTER_NAME"
kubectl get nodes
```

Use short-lived IAM/OIDC credentials. Do not put static access keys in scripts, shell history, or runbook notes.

## 2. Validation

Run the EKS wrapper, then Prometheus and functional validation:

```bash
bash ./validation/validate-aws.sh
bash ./validation/check-prometheus-targets.sh
bash ./validation/smoke-test.sh
```

PowerShell:

```powershell
pwsh ./validation/validate-aws.ps1
pwsh ./validation/check-prometheus-targets.ps1
pwsh ./validation/smoke-test.ps1
```

Manual spot checks:

```bash
kubectl get ns guestbook monitoring
kubectl -n guestbook get pods -o wide
kubectl -n monitoring get pods
kubectl get servicemonitor -A
kubectl -n monitoring get svc
```

If Grafana has no external address, use a diagnostic port-forward:

```bash
kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80
```

## 3. Operations Notes

Daily checks:

```bash
kubectl get nodes
kubectl -n guestbook get pods
kubectl -n monitoring get pods
bash ./validation/validate-aws.sh
```

Weekly checks:

```bash
kubectl -n monitoring get events --sort-by=.lastTimestamp
kubectl -n guestbook get events --sort-by=.lastTimestamp
kubectl -n monitoring get svc
aws elbv2 describe-load-balancers --region "$AWS_REGION" --output table
```

Security controls:

| Control | Requirement |
|---|---|
| Credentials | Use IAM Identity Center, web identity, or approved short-lived role assumption |
| Static keys | Do not store `aws_access_key_id` or `aws_secret_access_key` in repo, scripts, or pipeline variables |
| Grafana exposure | Prefer private/internal load balancer or port-forward unless public exposure is explicitly approved |
| Namespace isolation | Keep `guestbook` and `monitoring` separate |
| Least privilege | Grant only required EKS and Kubernetes permissions |

## 4. Troubleshooting

Grafana external address missing:

```bash
kubectl -n monitoring get svc monitoring-grafana
kubectl -n monitoring describe svc monitoring-grafana
kubectl -n monitoring get events --sort-by=.lastTimestamp
```

Common causes:

| Cause | Resolution |
|---|---|
| Load balancer provisioning delay | Wait and re-check service events |
| Subnet tagging issue | Confirm EKS subnets are tagged for Kubernetes load balancers |
| AWS Load Balancer Controller dependency | Check controller install and IAM role if the service requires it |
| Quota or security group issue | Review ELB quotas, security groups, and service events |

ServiceMonitor target missing:

```bash
kubectl get servicemonitor -A
kubectl -n guestbook get svc --show-labels
kubectl -n guestbook get endpoints
```

The most common cause is a ServiceMonitor selector that does not match the Guestbook service labels.

## 5. Acceptance Criteria

| Requirement | Acceptance test | Status |
|---|---|---|
| Cluster reachable | `kubectl get nodes` succeeds | Pending |
| Guestbook deployed | `kubectl -n guestbook get pods` all Running | Pending |
| Monitoring deployed | Prometheus, Grafana, operator, kube-state-metrics Running | Pending |
| ServiceMonitor present | `kubectl get servicemonitor -A` shows Guestbook monitor | Pending |
| Target UP | `check-prometheus-targets.*` reports guestbook target UP | Pending |
| Functional traffic observable | `smoke-test.*` shows metric increase or records metric gap | Pending |

