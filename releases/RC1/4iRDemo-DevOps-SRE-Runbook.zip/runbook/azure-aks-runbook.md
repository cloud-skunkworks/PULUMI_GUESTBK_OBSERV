# Operations Runbook: Guestbook Monitoring on Azure AKS

**Runbook name:** Guestbook Kubernetes Monitoring — Azure AKS Target
**Audience:** DevOps Engineers, SREs, Platform Engineers, Cloud Operations Leads, IT Managers
**Target:** Azure Kubernetes Service (AKS), managed multi-node cluster
**Technology scope:** Pulumi, Kubernetes, Helm, kube-prometheus-stack, Prometheus, Grafana, ServiceMonitor
**Grafana exposure:** `LoadBalancer` (Azure public IP) or internal LB for hardened environments
**Last updated:** 2026-06-01

> This runbook covers Azure AKS only. For the local zero-cost rehearsal target see `docker-desktop-k8s-runbook.md`. Run the scripts in `validation/` after every deploy.

---

## 1. TOGAF Architecture View (AKS)

| TOGAF View | Focus |
|---|---|
| Business Architecture | AKS is the cloud delivery target. IT Manager approves subscription, node SKU, LoadBalancer cost, and acceptance criteria. Outcome: a monitored Guestbook reachable by the SRE team with Grafana dashboards. |
| Application Architecture | Guestbook frontend + Redis leader/replica in `guestbook`; frontend exposes `/metrics` (`guestbook_http_requests_total`). kube-prometheus-stack in `monitoring` scrapes via `ServiceMonitor`. Grafana renders the dashboard. |
| Data Architecture | Prometheus stores time-series with labels `namespace`, `component`, `pod`. Retention per chart default. No business data beyond sample Guestbook entries in Redis. |
| Technology Architecture | AKS managed control plane + node pool. Pulumi (`cloudProvider=azure`) applies the kube-prometheus-stack Helm chart. Grafana service type `LoadBalancer` → Azure Standard Load Balancer public IP. |
| Security Architecture | Grafana password is a Pulumi secret. Namespaces separated. Avoid public Grafana unless approved — prefer internal LB or port-forward. Entra ID integration for cluster auth in production. No secrets in Git. |
| Operations Architecture | Sections 4–12 below: install, validate, routine ops, change, rollback, decommission, troubleshooting. |

---

## 2. Prerequisites and Tool Validation

Install on the SRE workstation or CI runner, then validate each:

| Tool | Purpose | Validation command |
|---|---|---|
| Azure CLI (`az`) | Authenticate to Azure, retrieve AKS credentials | `az version` |
| Pulumi CLI | Deploy Kubernetes resources | `pulumi version` |
| Node.js LTS | Run the TypeScript Pulumi project | `node --version` |
| npm | Install project dependencies | `npm --version` |
| kubectl | Interact with the cluster | `kubectl version --client` |
| Helm CLI | Inspect Helm releases (optional, deploy is via Pulumi) | `helm version` |
| jq | Parse JSON in validation scripts | `jq --version` |
| Git | Source control | `git --version` |

Run a one-shot check (PowerShell 7+):

```powershell
foreach ($t in 'az','pulumi','node','npm','kubectl','jq','git') {
  $found = Get-Command $t -ErrorAction SilentlyContinue
  if ($found) { Write-Host "PASS  $t -> $($found.Source)" } else { Write-Host "FAIL  $t not found" }
}
```

---

## 3. Azure Authentication and Cluster Access

### 3.1 Login and select subscription

```bash
az login
az account show --output table
az account set --subscription "<SUBSCRIPTION_ID_OR_NAME>"
```

Confirm the active subscription is the intended non-production target before proceeding.

### 3.2 Configure kubectl for AKS

```bash
export RESOURCE_GROUP=rg-guestbook-monitoring
export AKS_CLUSTER_NAME=guestbook-monitoring-aks

az aks get-credentials \
  --resource-group "$RESOURCE_GROUP" \
  --name "$AKS_CLUSTER_NAME" \
  --overwrite-existing
```

PowerShell equivalent:

```powershell
$env:RESOURCE_GROUP   = 'rg-guestbook-monitoring'
$env:AKS_CLUSTER_NAME = 'guestbook-monitoring-aks'

az aks get-credentials `
  --resource-group $env:RESOURCE_GROUP `
  --name $env:AKS_CLUSTER_NAME `
  --overwrite-existing
```

### 3.3 Verify cluster access

```bash
kubectl config current-context     # should be the AKS cluster name
kubectl get nodes
kubectl get namespaces
```

The current context name should match `$AKS_CLUSTER_NAME`. The `validate-azure` script asserts this.

### 3.4 Optional: create a lab AKS cluster

Use only if no cluster exists. This incurs cost.

```bash
export LOCATION=canadacentral
export RESOURCE_GROUP=rg-guestbook-monitoring
export AKS_CLUSTER_NAME=guestbook-monitoring-aks

az group create \
  --name "$RESOURCE_GROUP" \
  --location "$LOCATION"

az aks create \
  --resource-group "$RESOURCE_GROUP" \
  --name "$AKS_CLUSTER_NAME" \
  --node-count 2 \
  --node-vm-size Standard_D2s_v5 \
  --generate-ssh-keys

az aks get-credentials \
  --resource-group "$RESOURCE_GROUP" \
  --name "$AKS_CLUSTER_NAME" \
  --overwrite-existing
```

Node sizing note: `Standard_D2s_v5` (2 vCPU / 8 GiB) x2 is the practical minimum for kube-prometheus-stack plus Guestbook. If Prometheus or the operator stays `Pending`, scale up the node pool (`az aks scale`) or use a larger SKU.

---

## 4. Pulumi Configuration (Azure)

From the Pulumi project root after `npm install`:

```bash
pulumi stack select dev || pulumi stack init dev

pulumi config set cloudProvider azure
pulumi config set appNamespace guestbook
pulumi config set monitoringNamespace monitoring
pulumi config set grafanaServiceType LoadBalancer
pulumi config set grafanaAdminUser admin
pulumi config set --secret grafanaAdminPassword 'CHANGE-ME-STRONG-PASSWORD'
pulumi config set enableDashboard true
```

Key Azure-specific choices:

- `cloudProvider=azure` selects Azure-aware defaults in the program.
- `grafanaServiceType=LoadBalancer` provisions an Azure Standard Load Balancer with a public IP. For hardened environments use an **internal** LB (Section 11.4).
- `grafanaAdminPassword` is stored encrypted as a Pulumi secret. Never set it as a plain config value and never commit `Pulumi.dev.yaml` with a decrypted secret.

Verify config (the password shows as `[secret]`):

```bash
pulumi config
```

---

## 5. Preview and Deploy

```bash
pulumi preview
```

Review the plan for: `guestbook` and `monitoring` namespaces; Guestbook frontend + Redis leader/replica; kube-prometheus-stack (Prometheus Operator, Prometheus, Grafana, kube-state-metrics); the `guestbook-frontend` ServiceMonitor; and the Grafana `LoadBalancer` service.

Deploy:

```bash
pulumi up
```

Approve only if the preview matches expectations.

---

## 6. Expected Outputs

```bash
pulumi stack output
```

```text
appNamespace:          guestbook
monitoringNamespace:   monitoring
grafanaServiceType:    LoadBalancer
grafanaAdminUser:      admin
grafanaAdminPassword:  [secret]
grafanaUrl:            http://<azure-public-ip>:3000
prometheusServiceName: prometheus-operated
guestbookFrontendService: guestbook-frontend
serviceMonitorName:    guestbook-frontend
```

The Azure LoadBalancer IP may take 1–3 minutes to populate. Until then `grafanaUrl` / `EXTERNAL-IP` shows `<pending>`.

Retrieve credentials for handoff:

```bash
pulumi stack output grafanaAdminUser
pulumi stack output grafanaAdminPassword --show-secrets
```

---

## 7. Validation

### 7.1 Automated (run the scripts)

```bash
# Azure-specific wrapper: az account, AKS context, Grafana EXTERNAL-IP, then core checks
bash ./validation/validate-azure.sh
# or, on Windows
pwsh ./validation/validate-azure.ps1

# Prometheus target health for the guestbook job
bash ./validation/check-prometheus-targets.sh

# End-to-end: traffic increases guestbook_http_requests_total
bash ./validation/smoke-test.sh
```

Each script exits non-zero if any check fails. See `validation/VALIDATION-TESTS.md`.

### 7.2 Manual spot checks

```bash
kubectl get ns guestbook monitoring
kubectl -n guestbook get pods -o wide
kubectl -n monitoring get pods
kubectl get servicemonitor -A
kubectl get crd | grep monitoring.coreos.com
kubectl -n monitoring get svc                # find the Grafana LoadBalancer EXTERNAL-IP
```

Grafana access (LoadBalancer):

```bash
pulumi stack output grafanaUrl
# open http://<external-ip>:3000 and log in with the Pulumi outputs
```

If `EXTERNAL-IP` is `<pending>`, use port-forward while you investigate (Section 11.1):

```bash
kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80
# open http://localhost:3000
```

---

## 8. Routine Operations

### 8.1 Daily

```bash
kubectl get nodes
kubectl -n guestbook get pods
kubectl -n monitoring get pods
kubectl get servicemonitor -A
bash ./validation/validate-azure.sh        # fast PASS/FAIL gate
```

Check the Grafana dashboard for missing data, target-down conditions, pod restarts, and CPU/memory saturation.

### 8.2 Weekly

```bash
pulumi preview --diff                       # detect drift
kubectl -n monitoring get events --sort-by=.lastTimestamp
kubectl -n guestbook  get events --sort-by=.lastTimestamp
kubectl -n monitoring get svc               # confirm no unintended public IP
az network lb list -g MC_${RESOURCE_GROUP}_${AKS_CLUSTER_NAME}_${LOCATION} -o table  # review LB cost
```

Review Helm chart version, Pulumi drift, secret storage, dashboard load, and public-endpoint exposure.

### 8.3 Monthly

1. Rotate the Grafana admin password (Section 9.3) in non-lab environments.
2. Upgrade the kube-prometheus-stack chart in a test stack before dev/prod.
3. Review Prometheus retention/storage.
4. Review RBAC and Entra ID group assignments on the cluster.
5. Audit for any Grafana/Prometheus service unintentionally exposed publicly.
6. Export/back up Grafana dashboards.

---

## 9. Change Management

### 9.1 Standard change flow

1. Create a Git branch.
2. Update Pulumi code or dashboard JSON.
3. `npm run build` / lint locally.
4. `pulumi preview` — attach output to the change ticket.
5. Obtain approval (production requires change approval + security validation + pipeline policy checks).
6. `pulumi up`.
7. Run `validation/validate-azure.*` and record results.
8. Update runbook notes if behaviour changed.

### 9.2 Emergency change flow

Manual `kubectl` is allowed only for break-glass recovery. Afterwards: record the command, time, and reason; convert it to Pulumi code; run `pulumi preview` to clear drift; run `pulumi up` to reconcile.

### 9.3 Rotate Grafana password

```bash
pulumi config set --secret grafanaAdminPassword 'NEW-STRONG-PASSWORD'
pulumi up
kubectl -n monitoring rollout restart deploy/monitoring-grafana   # if chart does not auto-reload
```

---

## 10. Rollback and Decommission

### 10.1 Roll back the last change

```bash
git log --oneline
git revert <commit-sha>
npm install
pulumi preview
pulumi up
```

### 10.2 Disable a feature without full teardown

```bash
pulumi config set enableDashboard false && pulumi up
kubectl -n monitoring delete servicemonitor guestbook-frontend
```

### 10.3 Destroy the Pulumi stack

```bash
pulumi stack select dev
pulumi destroy
pulumi stack rm dev      # optional
```

Then confirm cloud resources created by Kubernetes are gone:

```bash
kubectl get ns guestbook monitoring          # expect NotFound after destroy
az network public-ip list -g MC_${RESOURCE_GROUP}_${AKS_CLUSTER_NAME}_${LOCATION} -o table
```

If the LoadBalancer public IP lingers, delete the Grafana service first, then re-run destroy:

```bash
kubectl -n monitoring delete svc monitoring-grafana
```

### 10.4 Delete the lab cluster / resource group

Only for a disposable lab with no shared assets:

```bash
az group delete --name "$RESOURCE_GROUP" --yes --no-wait
```

This removes the AKS cluster, node pool, LoadBalancers, public IPs, and disks in that resource group.

---

## 11. Azure-Specific Troubleshooting

### 11.1 Grafana LoadBalancer has no EXTERNAL-IP

```bash
kubectl -n monitoring get svc monitoring-grafana
kubectl -n monitoring describe svc monitoring-grafana
kubectl -n monitoring get events --sort-by=.lastTimestamp
```

| Cause | Resolution |
|---|---|
| Provisioning delay | Wait 1–3 minutes; Azure LB allocation is asynchronous |
| Public IP quota exhausted | `az network list-usages --location $LOCATION -o table`; request quota increase |
| Internal LB annotation but no private subnet | Confirm subnet exists and has free addresses |
| Cloud provider controller error | Check service events; check `kube-system` cloud-controller logs |

Temporary workaround while investigating:

```bash
kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80
```

### 11.2 Node / compute quota errors during deploy

```bash
az vm list-usage --location "$LOCATION" -o table
az aks scale -g "$RESOURCE_GROUP" -n "$AKS_CLUSTER_NAME" --node-count 3
```

Symptom: Prometheus / operator pods stuck `Pending` with `Insufficient cpu/memory`. Scale the node pool or use a larger SKU.

### 11.3 Entra ID (Azure AD) access denied

```bash
az aks show -g "$RESOURCE_GROUP" -n "$AKS_CLUSTER_NAME" --query aadProfile
kubectl get nodes      # triggers an Entra ID device login if AAD-integrated
```

| Cause | Resolution |
|---|---|
| Missing Kubernetes RBAC role assignment | Assign `Azure Kubernetes Service RBAC Reader/Writer` or `Cluster User` role to the operator |
| Stale token | `az account get-access-token` to refresh; re-run `az aks get-credentials --overwrite-existing` |
| Wrong tenant | `az login --tenant <tenant-id>` then re-select subscription |

### 11.4 Hardening: internal LB / private cluster

To avoid a public Grafana IP, annotate the service for an internal Azure LB (set via Pulumi/Helm values, not manually in prod):

```yaml
service.beta.kubernetes.io/azure-load-balancer-internal: "true"
```

For a private API server, create the cluster with `--enable-private-cluster`. Combine with `kubectl port-forward` or an internal ingress for Grafana access from within the VNet/jumpbox only.

### 11.5 Cluster unreachable

```bash
kubectl cluster-info
kubectl config current-context
az aks get-credentials -g "$RESOURCE_GROUP" -n "$AKS_CLUSTER_NAME" --overwrite-existing
```

---

## 12. Security Controls (AKS)

| Control | Requirement |
|---|---|
| Grafana credentials | Pulumi secret only; retrieve with `pulumi stack output grafanaAdminPassword --show-secrets` |
| Public exposure | Avoid public Grafana unless explicitly approved; prefer internal LB (Section 11.4) or port-forward |
| Cluster auth | Integrate with Entra ID; avoid long-lived shared admin credentials |
| Networking | Use private cluster or internal LB for enterprise; restrict NSG/subnet access |
| Secrets in Git | Never commit decrypted `Pulumi.dev.yaml` secrets or `.env` files |
| Least privilege | Scoped AKS RBAC role; cluster-admin only for initial Operator CRD install in lab |
| Audit | Record subscription, resource group, cluster, stack, commit SHA, operator, timestamp on handoff |

---

## 13. AKS Acceptance Criteria

| Requirement | Acceptance test | Status |
|---|---|---|
| Cluster reachable | `kubectl get nodes` succeeds; context == AKS name | Pending |
| Guestbook deployed | `kubectl -n guestbook get pods` all Running | Pending |
| Monitoring deployed | Prometheus, Grafana, operator, kube-state-metrics Running | Pending |
| ServiceMonitor present | `kubectl get servicemonitor -A` shows `guestbook-frontend` | Pending |
| Grafana exposed | LoadBalancer has EXTERNAL-IP (or port-forward documented) | Pending |
| Credentials output | `pulumi stack output grafanaAdminPassword --show-secrets` returns value | Pending |
| Target UP | `check-prometheus-targets.*` reports guestbook target `UP` | Pending |
| Traffic observable | `smoke-test.*` shows `guestbook_http_requests_total` increased | Pending |
| Cleanup documented | Section 10 destroy + `az group delete` verified | Pending |
