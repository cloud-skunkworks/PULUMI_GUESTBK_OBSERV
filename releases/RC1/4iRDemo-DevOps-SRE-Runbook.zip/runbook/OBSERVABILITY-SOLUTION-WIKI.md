# Wiki: Guestbook Observability Solution for Azure DevOps and SRE Teams

**Audience:** Junior Azure DevOps Engineers, SRE Engineers, Platform Engineers  
**Primary production target:** Azure Kubernetes Service (AKS)  
**Pattern:** Pulumi-managed Kubernetes application + Prometheus Operator + Grafana  
**Purpose:** Teach how the demo observability solution works and how to approach a production rollout safely.

---

## 1. What This Solution Does

This solution deploys a small Kubernetes Guestbook application and adds a complete monitoring layer around it.

At a high level, it gives your team:

1. A `guestbook` namespace for the application workload.
2. A `monitoring` namespace for Prometheus, Grafana, and supporting observability components.
3. An instrumented frontend service that exposes real Prometheus metrics at `/metrics`.
4. A Prometheus Operator `ServiceMonitor` that tells Prometheus how to scrape the frontend.
5. A Grafana dashboard that visualizes request rate, error rate, latency, CPU, memory, and restarts.
6. Pulumi stack outputs that show how to access Grafana and Prometheus.
7. Validation scripts that prove the application, scrape target, and dashboard data path are working.

The important idea is simple: the app emits metrics, Prometheus scrapes them, Grafana displays them, and SREs use the data to detect and diagnose issues.

---

## 2. Why This Matters in Production

In production, observability is not decoration. It is how SREs answer operational questions quickly:

- Is the service up?
- Is it serving traffic?
- Are requests getting slower?
- Are errors increasing?
- Are pods restarting?
- Are CPU or memory limits too low?
- Did the last deployment make things worse?

Without telemetry, engineers guess. With telemetry, engineers investigate.

For a regulated FinTech or payments platform, observability also supports auditability and operational control. Teams need evidence that systems are monitored, alerts are defined, secrets are protected, access is controlled, and incidents can be reconstructed without exposing payment data or customer PII.

---

## 3. How The Architecture Works

The solution is split into two namespaces:

| Namespace | Purpose |
|---|---|
| `guestbook` | Runs the application frontend, Redis master, and Redis replica. |
| `monitoring` | Runs Prometheus Operator, Prometheus, Grafana, kube-state-metrics, node-exporter, dashboards, and ServiceMonitor resources. |

The core flow looks like this:

```text
Guestbook frontend
  |
  | exposes /metrics
  v
Guestbook Service
  |
  | selected by ServiceMonitor
  v
Prometheus Operator
  |
  | configures Prometheus scrape job
  v
Prometheus
  |
  | stores time-series metrics
  v
Grafana
  |
  | visualizes dashboards and supports alerts
  v
SRE / DevOps operator
```

Pulumi manages the Kubernetes resources. That means engineers should not manually install Helm charts or apply YAML for the managed components. The desired state lives in code.

---

## 4. What Metrics Are Collected

The frontend exposes real application metrics:

| Metric | Meaning |
|---|---|
| `guestbook_http_requests_total` | Total frontend requests served. |
| `guestbook_http_request_errors_total` | Total frontend error responses. |
| `guestbook_http_request_duration_seconds` | Request latency histogram. |

The monitoring stack also collects infrastructure metrics from Kubernetes, kubelet/cAdvisor, and kube-state-metrics:

| Metric Family | Meaning |
|---|---|
| `container_cpu_usage_seconds_total` | CPU consumed by containers. |
| `container_memory_working_set_bytes` | Memory used by containers. |
| `kube_pod_container_status_restarts_total` | Container restart count. |
| `up` | Whether Prometheus can scrape a target. |

This distinction matters. Application metrics tell you what users experience. Infrastructure metrics tell you how the platform is behaving. Production SREs need both.

---

## 5. How Prometheus Finds The Guestbook Metrics

Prometheus does not magically know what to scrape.

The solution uses a Prometheus Operator `ServiceMonitor`. A `ServiceMonitor` is a Kubernetes custom resource that says:

- Look in this namespace.
- Find Services with these labels.
- Scrape this named port.
- Use this path.
- Scrape every 15 seconds.

In this project, the frontend Service has stable Kubernetes labels, and the ServiceMonitor selects those labels. This is one of the most common failure points in real deployments. If the Service labels and ServiceMonitor selector do not match exactly, Prometheus will not scrape the app.

Junior engineers should learn this diagnostic pattern early:

```powershell
kubectl get svc guestbook-frontend -n guestbook --show-labels
kubectl get servicemonitor guestbook-frontend -n monitoring -o yaml
kubectl -n monitoring port-forward svc/prometheus-operated 9090:9090
```

Then open Prometheus and check **Status → Targets**. The Guestbook target should be `UP`.

---

## 6. How Grafana Fits In

Grafana is the visualization layer. It does not collect metrics itself. It queries Prometheus and renders dashboards.

This solution provisions a dashboard as code. That is the right production habit:

- Dashboard JSON lives in the repository.
- Pulumi creates a ConfigMap for the dashboard.
- Grafana sidecar imports the dashboard automatically.
- Engineers do not manually build dashboards in the UI and forget to commit them.

For production teams, dashboards should be treated like code. Review them, version them, promote them through environments, and avoid manual-only configuration.

---

## 7. What Pulumi Is Responsible For

Pulumi is the deployment control plane for this solution. It creates:

- Namespaces.
- Guestbook Deployments and Services.
- Optional RBAC and NetworkPolicies.
- kube-prometheus-stack Helm release.
- ServiceMonitor.
- Grafana dashboard ConfigMap.
- Stack outputs for access and validation.

Your engineers should think of Pulumi as the source of truth. A human can use `kubectl` to inspect and troubleshoot, but production changes should go through Pulumi and the CI/CD pipeline.

The safe deployment workflow is:

```powershell
npm install
npm run typecheck
pulumi pvalidate
pulumi up
```

For production, replace direct `pulumi up` from a laptop with an approved pipeline.

---

## 8. How Junior SREs Should Implement This In Production

Production implementation should be slower and more deliberate than the demo. The right sequence is:

## Step 1: Understand The Existing Platform

Before deploying anything, confirm:

- Which AKS cluster is the target?
- Is it non-production or production?
- Is Azure Monitor already installed?
- Is there an existing Prometheus/Grafana platform?
- Are NetworkPolicies enforced by the cluster CNI?
- Is Grafana allowed to be exposed publicly?
- Which identity should the pipeline use?
- Which team owns alerts after deployment?

Never install a second monitoring stack into production without checking whether a platform standard already exists.

## Step 2: Start In Dev Or A Sandbox AKS Cluster

Use a non-production AKS cluster first.

Recommended config:

```powershell
pulumi config set cloudProvider azure
pulumi config set appNamespace guestbook
pulumi config set monitoringNamespace monitoring
pulumi config set grafanaServiceType ClusterIP
pulumi config set grafanaAdminUser admin
pulumi config set --secret grafanaAdminPassword '<approved-secret-value>'
pulumi config set enableDashboard true
pulumi config set enableRbac true
pulumi config set enableNetworkPolicies false
```

Use `ClusterIP` or an internal-only exposure model until the security team approves external access.

## Step 3: Use OIDC Pipeline Authentication

Do not use long-lived service principal secrets in Azure DevOps or GitHub Actions.

Use Workload Identity Federation / OIDC for pipeline authentication. The pipeline should receive a short-lived token and assume only the Azure permissions required for the target environment.

For AKS deployment, the pipeline usually needs:

- Access to the AKS cluster.
- Permission to create Kubernetes resources.
- Permission to create LoadBalancer resources only if external exposure is approved.

Avoid broad subscription-wide access for production.

## Step 4: Store Secrets Correctly

Grafana admin password must be stored as a Pulumi secret or sourced from an approved secret manager.

Never commit:

- Grafana passwords.
- Azure credentials.
- kubeconfig files.
- `.env` or `.env.local`.
- Service principal secrets.
- API keys.

For a real FinTech platform, prefer Azure Key Vault and managed identity patterns.

## Step 5: Deploy Through A Controlled Pipeline

A production pipeline should include gates:

```text
Pull request
  -> static checks
  -> npm typecheck
  -> Pulumi pvalidate
  -> security validate
  -> change approval
  -> Pulumi up
  -> validation scripts
  -> evidence capture
```

Production `pulumi up` should happen only after pvalidate validate and approval.

## Step 6: Validate Function, Not Just Installation

Do not stop after pods are `Running`.

A real validation proves the telemetry path:

1. Generate frontend traffic.
2. Confirm the request counter increases.
3. Confirm Prometheus target is `UP`.
4. Confirm Grafana panels show data.
5. Confirm restart, CPU, and memory panels render.

Use the included scripts:

```powershell
pwsh ./validation/validate-azure.ps1
pwsh ./validation/check-prometheus-targets.ps1
pwsh ./validation/smoke-test.ps1
```

Passing validation means the solution is observable, not merely installed.

## Step 7: Convert Dashboards Into Alerts

Dashboards help humans investigate. Alerts wake humans up.

For production, define alert rules as code. Start with:

| Alert | Example Condition |
|---|---|
| Target down | `up{namespace="guestbook"} == 0` |
| High error rate | Error rate above agreed threshold. |
| High latency | p95 latency above SLO threshold. |
| Restart storm | Pod restarts increasing rapidly. |
| Resource pressure | CPU/memory near limits for sustained period. |

Do not alert on every small fluctuation. Alerts should represent user impact or a credible path to user impact.

## Step 8: Define SLOs And Ownership

An SLO is a reliability target. For example:

- 99.9% of frontend requests succeed over 30 days.
- 95% of requests complete under 500 ms.
- No more than one critical restart event per day.

Every production alert needs an owner:

- Who receives the alert?
- What runbook do they follow?
- What is the escalation path?
- What is the expected response time?

Monitoring without ownership becomes noise.

---

## 9. Production Hardening Checklist

Before this pattern goes into production, complete this checklist:

- [ ] Use private AKS or restricted API access where required.
- [ ] Use OIDC workload identity for CI/CD authentication.
- [ ] Keep Grafana `ClusterIP` or internal-only unless public exposure is approved.
- [ ] Store Grafana credentials in Pulumi secrets or Azure Key Vault.
- [ ] Confirm `.env`, `.env.local`, and Pulumi stack files with secrets are gitignored.
- [ ] Enable NetworkPolicies only after confirming the CNI enforces them.
- [ ] Confirm ServiceMonitor selectors match Service labels.
- [ ] Add alert rules as code.
- [ ] Define SLOs and escalation ownership.
- [ ] Capture validation evidence after deployment.
- [ ] Document any cluster-scoped RBAC used by Prometheus Operator.
- [ ] Validate no PII, card data, or secrets are emitted in logs or metric labels.

---

## 10. Common Failure Modes

| Symptom | Likely Cause | First Check |
|---|---|---|
| Grafana dashboard is empty | Prometheus has no data or dashboard query labels do not match. | Query `guestbook_http_requests_total` in Prometheus. |
| Prometheus target missing | ServiceMonitor selector does not match Service labels. | Compare Service labels and ServiceMonitor YAML. |
| Target is down | Wrong port name, wrong path, pod not ready, or NetworkPolicy blocking scrape. | Check `/metrics` with port-forward. |
| Grafana external IP pending | Local cluster or cloud load balancer not provisioned yet. | Use port-forward or switch service type. |
| Pods pending | Cluster resource pressure or chart too large for node size. | `kubectl describe pod` and node capacity. |
| Metrics counter does not increase | No traffic generated or app instrumentation not scraped. | Run smoke test and check Prometheus targets. |

---

## 11. How To Think Like An SRE When Implementing This

Junior engineers should approach production observability with four questions:

1. **Can we see it?**  
   Are metrics, logs, traces, dashboards, and alerts available?

2. **Can we trust it?**  
   Are metrics real, correctly named, and validated end to end?

3. **Can we act on it?**  
   Are alerts tied to runbooks and owners?

4. **Can we prove it?**  
   Can we show deployment evidence, validation output, and audit-safe configuration?

The demo teaches the core mechanics. Production requires discipline: secure access, least privilege, validated changes, alert ownership, and evidence.

---

## 12. Recommended Learning Path For Junior Azure DevOps SREs

1. Deploy locally on Docker Desktop.
2. Run the validation scripts.
3. Break the ServiceMonitor selector and observe the failure.
4. Fix the selector and confirm the target returns to `UP`.
5. Deploy to a non-production AKS cluster.
6. Switch Grafana from `ClusterIP` to approved exposure.
7. Add one alert rule as code.
8. Write a short incident note from a simulated failure.
9. Repeat the deployment through a pipeline using OIDC.
10. Present the architecture and validation evidence to a senior implementation approver.

That learning path builds practical SRE instincts: deploy, observe, break, diagnose, repair, document.

---

## 13. Final Guidance

This solution is a teaching-friendly implementation of a production observability pattern. The exact Guestbook app is not important. The pattern is.

The production lesson is:

- Keep infrastructure declarative.
- Keep secrets out of code.
- Keep monitoring separated from workloads.
- Make metrics real.
- Validate the full telemetry path.
- Promote dashboards and alerts as code.
- Require approval before public exposure.
- Give every alert an owner and a runbook.

If junior SREs internalize those habits, they will be much better prepared to operate real Azure Kubernetes workloads in regulated environments.
